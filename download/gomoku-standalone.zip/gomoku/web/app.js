/* 交互与状态：调接口、落子、动画、轮询同步。
 *
 * 手感约定：
 *   - 点交叉点就落子，不搞"先选后放"；没轮到你 / 有子 / 已结束都会给一句提示
 *   - 鼠标悬停时先给一个半透明的"预落子"，落哪儿看得见
 *   - 落子动画没播完也能继续点，不做输入锁（锁了就会"点不动"）
 */

/* 房间码：链接里带着它，朋友打开同一个链接就进同一盘棋 */
let ROOM = 'MAIN';

/* 客户端标识：用来分配"谁执黑谁执白"，刷新后不变 */
function clientId() {
  const KEY = 'gomoku-client-id';
  let id = localStorage.getItem(KEY);
  if (!id) {
    id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
    localStorage.setItem(KEY, id);
  }
  return id;
}
// 调试/演示时可以用 ?client=xxx 指定一个身份（同机开两个标签页对下也方便）
const CLIENT = (new URLSearchParams(location.search).get('client') || '').slice(0, 40) || clientId();

function makeRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 4; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

async function getJSON(url, tries = 2) {
  let lastError;
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, { cache: 'no-store' });
      return await r.json();
    } catch (e) {
      lastError = e;
      if (i < tries - 1) await sleep(400);
    }
  }
  throw lastError;
}

function withRoom(url) {
  const u = new URL(url, location.origin);
  u.searchParams.set('room', ROOM);
  u.searchParams.set('client', CLIENT);
  return u.pathname + '?' + u.searchParams.toString();
}

const api = {
  async get(url) {
    return getJSON(withRoom(url), 2);
  },
  async post(url, body) {
    const r = await fetch(withRoom(url), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}),
    });
    return r.json();
  },
};

const el = {
  canvas: document.getElementById('board'),
  status: document.getElementById('status'),
  toast: document.getElementById('toast'),
  seat: document.getElementById('seat'),
  home: document.getElementById('home'),
  join: document.getElementById('join'),
  joinCode: document.getElementById('join-code'),
  joinErr: document.getElementById('join-err'),
  undoBtn: document.getElementById('btn-undo'),
  undoModal: document.getElementById('undo-modal'),
  undoText: document.getElementById('undo-text'),
  invite: document.getElementById('invite'),
  roomCode: document.getElementById('room-code'),
  levelGroup: document.getElementById('level-group'),
  modeChips: document.getElementById('mode-chips'),
  levelChips: document.getElementById('level-chips'),
  soundBtn: document.getElementById('btn-sound'),
  statMoves: document.getElementById('stat-moves'),
  statLast: document.getElementById('stat-last'),
  offline: document.getElementById('offline'),
};

const view = new BoardView(el.canvas);

const app = {
  state: null,
  busy: false,
  gameId: 0,
  isHost: false,
  level: '普通',
  mode: 'ai',
  lockedPvp: false,        // 开房间/加入房间进来的对局固定双人，不允许切人机
  freezeRound: false,      // 截图/演示时不要自动开下一局
};

const SIDE_NAME = { 1: '黑方', 2: '白方' };

/* ---------------------------------------------------------------- 工具 */
let toastTimer = null;
function toast(msg) {
  el.toast.textContent = msg;
  el.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.toast.classList.remove('show'), 1700);
}

function myTurn() {
  const s = app.state;
  if (!s || s.over || app.busy) return false;
  if (app.mode === 'pvp') {
    if ((s.players || 1) >= 2) return !!s.you && s.you === s.turn;
    return true;                    // 同屏双人：一个人管两边
  }
  return s.turn === 1;              // 人机：人执黑先走
}

function isSpectator() {
  const s = app.state;
  return !!s && (s.players || 1) >= 2 && !s.you;
}

function cellFromEvent(ev) {
  const rect = el.canvas.getBoundingClientRect();
  const scale = BOARD.W / rect.width;
  return view.cellAt((ev.clientX - rect.left) * scale, (ev.clientY - rect.top) * scale);
}

/* ---------------------------------------------------------------- 渲染 */
function adopt(state, opts = {}) {
  const prev = app.state;
  // 迟到的旧响应（轮询比请求先发、后到）：绝不能把棋盘倒回去
  if (prev && typeof state.rev === 'number' && typeof prev.rev === 'number'
      && state.rev < prev.rev) {
    return;
  }
  const wasOver = !!(prev && prev.over);
  app.state = state;
  app.mode = state.mode;
  app.level = state.level;
  if (app.busy && state.turn !== 2) app.busy = false;   // 局面已经轮到人，别再显示"思考中"

  // 落子动画只在这里播：历史"正好多一手"才播，重复同步同一个局面不会再播
  if (prev && prev.history && state.history
      && state.history.length === prev.history.length + 1 && state.last) {
    const [r, c] = state.last;
    const side = state.board?.[r]?.[c];
    if (side) {
      view.drop(r, c, side);
      Sound.place(side, opts.volume ?? 1);
    }
  }

  view.setState({
    board: state.board,
    turn: state.turn,
    last: state.last,
    line: state.line,
    over: state.over,
    winner: state.winner,
    ghostSide: myTurn() ? state.turn : null,
  });

  renderStatus();
  renderSeat();
  renderChips();
  renderStats();
  renderUndoButton();
  handleUndoRequest();
  scheduleNextRound();

  // 刚结束：等落子声先响完，再上一段胜利的钟声
  if (state.over && !wasOver && (state.winner === 1 || state.winner === 2)) {
    setTimeout(() => Sound.win(), 340);
  }
}

function renderStatus() {
  const s = app.state;
  if (!s) return;
  let text = '';
  let cls = '';

  if (s.over) {
    const who = s.winner === 1 ? '黑方胜' : s.winner === 2 ? '白方胜' : '和棋';
    text = s.reason ? `${who} · ${s.reason.replace(/^[黑白]方/, '')}` : who;
    cls = 'over';
  } else if (app.busy) {
    text = '电脑思考中…';
    cls = 'thinking';
  } else {
    const n = s.history ? s.history.length + 1 : 1;
    text = `${SIDE_NAME[s.turn]}落子 · 第 ${n} 手`;
  }

  el.status.textContent = text;
  el.status.className = 'status ' + cls;
}

function renderSeat() {
  const s = app.state;
  if (!s) return;

  const players = s.players || 1;
  let text = '';
  let mine = false;

  if (players < 2 && app.mode === 'ai') {
    text = s.turn === 1 && !s.over ? '你执黑 · 轮到你' : '你执黑';
    mine = s.turn === 1 && !s.over;
  } else if (players < 2) {
    text = '同屏双人 · 一人管两边';
  } else if (!s.you) {
    text = '观战中';
  } else {
    const turnNow = s.you === s.turn && !s.over;
    text = (s.you === 1 ? '你执黑' : '你执白') + ' · ' + (turnNow ? '轮到你' : '等对方');
    mine = turnNow;
  }

  el.seat.textContent = text;
  el.seat.className = 'seat' + (mine ? ' mine' : '');
}

function renderStats() {
  const s = app.state;
  if (!s) return;
  if (el.statMoves) el.statMoves.textContent = String(s.history ? s.history.length : 0);
  if (el.statLast) {
    const last = s.history && s.history.length ? s.history[s.history.length - 1].text : '—';
    el.statLast.textContent = last;
  }
}

function renderChips() {
  // 双人对战没有电脑，难度选项没意义
  if (el.levelGroup) el.levelGroup.hidden = app.mode !== 'ai';

  // 房间对局固定双人：对战模式切换整组隐藏，避免被切回人机
  const modeGroup = el.modeChips.closest('.group');
  if (modeGroup) modeGroup.hidden = !!app.lockedPvp;

  el.modeChips.querySelectorAll('.chip').forEach((b) => {
    b.classList.toggle('active', b.dataset.mode === app.mode);
  });
  el.levelChips.querySelectorAll('.chip').forEach((b) => {
    b.classList.toggle('active', b.dataset.level === app.level);
  });
  document.querySelectorAll('.home-levels .chip').forEach((b) => {
    b.classList.toggle('active', b.dataset.level === app.level);
  });
}

function renderUndoButton() {
  const s = app.state;
  if (!s || !el.undoBtn) return;
  if (s.mode === 'pvp') {
    const left = Math.max(0, (s.undoLimit || 3) - (s.undoUsed || 0));
    el.undoBtn.textContent = `悔棋 (${left})`;
    el.undoBtn.disabled = left === 0 || !!s.undoRequest;
  } else {
    el.undoBtn.textContent = '悔棋';
    el.undoBtn.disabled = !s.history || s.history.length === 0;
  }
}

/* ---------------------------------------------------------------- 悔棋 */
function handleUndoRequest() {
  const s = app.state;
  const req = s && s.undoRequest;
  if (req && s.you && req.by !== s.you && (s.players || 1) >= 2) {
    el.undoText.textContent = `对方请求悔棋（第 ${req.used + 1} 次）`;
    el.undoModal.hidden = false;
  } else {
    el.undoModal.hidden = true;
  }
}

async function respondUndo(accept) {
  el.undoModal.hidden = true;
  const res = await api.post('/api/undo/respond', { accept });
  if (!res.ok) {
    toast(res.error || '操作失败');
    return;
  }
  toast(accept ? '已同意悔棋' : '已拒绝');
  view.anims = [];
  if (accept) Sound.undo();
  adopt(res.state);
}

async function undo() {
  if (app.busy) {
    toast('等电脑走完这一步');
    return;
  }
  app.gameId += 1;
  const res = await api.post('/api/undo');
  if (!res.ok) {
    toast(res.error || '还没有落子');
    return;
  }
  if (res.pending) {
    toast('已请求悔棋，等对方同意');
    adopt(res.state);
    return;
  }
  view.anims = [];
  Sound.undo();
  adopt(res.state);
  toast('已悔棋');
}

/* ---------------------------------------------------------------- 自动下一局 */
let roundTimer = null;

function scheduleNextRound() {
  const s = app.state;
  if (!s || !s.over) {
    if (roundTimer) { clearInterval(roundTimer); roundTimer = null; }
    return;
  }
  if (roundTimer) return;
  if (app.freezeRound) return;

  let left = 5;
  const tick = () => {
    if (left > 0) {
      const who = app.state.winner === 1 ? '黑方' : app.state.winner === 2 ? '白方' : '和棋';
      el.status.textContent = `${who} · ${left} 秒后下一局`;
      left -= 1;
      return;
    }
    clearInterval(roundTimer);
    roundTimer = null;
    // 只让房主（或执黑者）发起，其他人靠轮询同步
    if (app.isHost || (app.state && app.state.you === 1)) newGame(app.mode);
  };
  tick();
  roundTimer = setInterval(tick, 1000);
}

/* ---------------------------------------------------------------- 动作 */
async function place(r, c) {
  const s = app.state;
  if (!s) return;
  if (s.over) {
    toast('对局结束，马上开下一局');
    return;
  }
  if (app.busy) {
    toast('等电脑走完这一步');
    return;
  }
  if (isSpectator()) {
    toast('你在观战，不能落子');
    return;
  }
  if (!myTurn()) {
    toast(`还没轮到你，现在是${SIDE_NAME[s.turn]}`);
    return;
  }
  if (s.board[r][c]) {
    toast('这里已经有子了');
    return;
  }

  const res = await api.post('/api/move', { r, c });
  if (!res.ok) {
    toast(res.error || '这一手落不下去');
    return;
  }

  adopt(res.state);

  if (!app.state.over && app.mode === 'ai' && app.state.turn === 2) aiTurn();
}

async function aiTurn() {
  if (app.busy) return;
  app.busy = true;
  renderStatus();

  const gid = app.gameId;
  const t0 = performance.now();
  let res = null;
  try {
    res = await api.post('/api/ai');
  } catch (e) {
    res = null;
  }
  const wait = 380 - (performance.now() - t0);
  if (wait > 0) await sleep(wait);

  app.busy = false;
  // 期间点了悔棋 / 新局的话，这次电脑应手已经过期，直接丢掉
  if (gid !== app.gameId) return;
  if (!res || !res.ok) {
    toast('电脑落子失败');
    renderStatus();
    return;
  }
  adopt(res.state, { volume: 0.9 });
}

async function newGame(mode) {
  app.gameId += 1;
  app.busy = false;
  const res = await api.post('/api/new', { mode, level: app.level });
  view.anims = [];
  adopt(res.state);
}

async function startGame(mode) {
  el.home.classList.add('hidden');
  await newGame(mode);
}

/* ---------------------------------------------------------------- 输入 */
function onPointerDown(ev) {
  if (!app.state) return;
  const cell = cellFromEvent(ev);
  if (!cell) return;
  ev.preventDefault();
  place(cell[0], cell[1]);
}

function onPointerMove(ev) {
  if (!app.state) return;
  const cell = cellFromEvent(ev);
  view.hover = cell;
  view.setState({ ghostSide: myTurn() ? app.state.turn : null });

  const occupied = cell && app.state.board?.[cell[0]]?.[cell[1]];
  el.canvas.style.cursor = myTurn() && cell && !occupied ? 'pointer' : 'default';
}

/* ---------------------------------------------------------------- 界面切换 */
function enterGame() {
  if (el.home) el.home.classList.add('hidden');
  if (el.join) el.join.hidden = true;
}

function showJoin() {
  if (el.home) el.home.classList.add('hidden');
  if (el.join) el.join.hidden = false;
  setTimeout(() => el.joinCode && el.joinCode.focus(), 200);
}

function showHome() {
  if (el.join) el.join.hidden = true;
  if (el.home) el.home.classList.remove('hidden');
}

/* ---------------------------------------------------------------- 加入房间 */
async function doJoin() {
  const code = (el.joinCode.value || '')
    .toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  if (code.length < 3) {
    el.joinErr.textContent = '房间码至少 3 位';
    return;
  }
  el.joinErr.textContent = '查询中…';
  try {
    const info = await getJSON(`/api/room?code=${code}`);
    if (!info.exists) {
      el.joinErr.textContent = '没有这个房间，跟房主确认一下房号';
      return;
    }
    const next = new URLSearchParams(location.search);
    next.set('room', code);
    next.set('join', '1');
    next.set('mode', 'pvp');        // 房间对局固定双人
    location.search = next.toString();
  } catch (e) {
    el.joinErr.textContent = '网络不太好，再试一次';
  }
}

/* ---------------------------------------------------------------- 音效开关 */
function renderSound() {
  if (!el.soundBtn) return;
  const on = Sound.isEnabled();
  el.soundBtn.classList.toggle('on', on);
  el.soundBtn.classList.toggle('off', !on);
  el.soundBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
  el.soundBtn.title = on ? '音效已开 · 点击关闭' : '音效已关 · 点击打开';
}

renderSound();

if (el.soundBtn) {
  el.soundBtn.addEventListener('click', (ev) => {
    ev.stopPropagation();
    Sound.setEnabled(!Sound.isEnabled());
    renderSound();
    if (Sound.isEnabled()) Sound.click();
  });
}

// 第一次触摸 / 按键时才允许出声（浏览器自动播放限制）
['pointerdown', 'keydown', 'touchstart'].forEach((type) => {
  window.addEventListener(type, () => Sound.unlock(), { once: true, capture: true });
});

/* ---------------------------------------------------------------- 绑定 */
el.canvas.addEventListener('pointerdown', onPointerDown);
el.canvas.addEventListener('pointermove', onPointerMove);
el.canvas.addEventListener('pointerleave', () => {
  view.hover = null;
});
el.canvas.addEventListener('contextmenu', (e) => e.preventDefault());

el.undoBtn.addEventListener('click', undo);

if (el.joinCode) {
  el.joinCode.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') doJoin();
  });
  document.getElementById('join-btn').addEventListener('click', doJoin);
  document.getElementById('join-back').addEventListener('click', showHome);
}
const joinEntry = document.getElementById('btn-join');
if (joinEntry) joinEntry.addEventListener('click', showJoin);
document.getElementById('undo-yes').addEventListener('click', () => respondUndo(true));
document.getElementById('undo-no').addEventListener('click', () => respondUndo(false));

el.modeChips.addEventListener('click', async (ev) => {
  const btn = ev.target.closest('.chip');
  if (!btn || btn.dataset.mode === app.mode) return;
  // 房间对局固定双人，不允许切回人机
  if (app.lockedPvp && btn.dataset.mode !== 'pvp') {
    toast('房间对局固定双人模式');
    return;
  }
  const res = await api.post('/api/settings', { mode: btn.dataset.mode });
  if (res.ok) {
    adopt(res.state);
    // 切回人机时如果正好轮到电脑，让它接着走
    if (app.mode === 'ai' && !res.state.over && res.state.turn === 2) aiTurn();
  }
});

el.levelChips.addEventListener('click', async (ev) => {
  const btn = ev.target.closest('.chip');
  if (!btn || btn.dataset.level === app.level) return;
  app.level = btn.dataset.level;
  renderChips();
  const res = await api.post('/api/settings', { level: app.level });
  if (res.ok) adopt(res.state);
});

document.addEventListener('click', (ev) => {
  const target = ev.target.closest('.btn, .big, .chip, .mini, .link-btn');
  if (target && target.id !== 'btn-sound') Sound.click();
});

document.querySelectorAll('[data-start]').forEach((btn) => {
  btn.addEventListener('click', () => startGame(btn.dataset.start));
});

document.querySelectorAll('.home-levels .chip').forEach((btn) => {
  btn.addEventListener('click', () => {
    app.level = btn.dataset.level;
    renderChips();
    api.post('/api/settings', { level: app.level });
  });
});

/* ---------------------------------------------------------------- 多端同步 */
let polling = false;
let pollFails = 0;
let ws = null;
let wsRetry = 0;
let wsTimer = null;

function setOffline(off) {
  if (el.offline) el.offline.hidden = !off;
}

function wsOpen() {
  return !!ws && ws.readyState === WebSocket.OPEN;
}

/* 收到一份新状态：撤销时清掉残留动画，其余交给 adopt（rev 守卫在 adopt 里） */
function applyIncoming(state, volume) {
  if (app.state && state.rev === app.state.rev) return;
  const prev = app.state;
  if (prev && state.history && prev.history && state.history.length < prev.history.length) {
    view.anims = [];
  }
  adopt(state, { volume });
}

/* WebSocket：状态一变服务器就推过来，不用等 900ms 轮询 */
function wsURL() {
  if (!location.host || !/^https?:$/.test(location.protocol)) return null;
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${proto}//${location.host}/ws?room=${encodeURIComponent(ROOM)}&client=${encodeURIComponent(CLIENT)}`;
}

function connectWS() {
  if (ws) return;
  const url = wsURL();
  if (!url) return;
  try {
    ws = new WebSocket(url);
  } catch (e) {
    ws = null;
    scheduleWS();
    return;
  }
  ws.onopen = () => {
    wsRetry = 0;
    setOffline(false);
  };
  ws.onmessage = (ev) => {
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch (e) {
      return;
    }
    if (msg && msg.t === 'state' && msg.state) {
      setOffline(false);
      applyIncoming(msg.state, 0.85);
    }
  };
  ws.onclose = () => {
    ws = null;
    scheduleWS();
  };
  ws.onerror = () => {
    try {
      ws && ws.close();
    } catch (e) {
      /* 忽略：onclose 会负责重连 */
    }
  };
}

function scheduleWS() {
  clearTimeout(wsTimer);
  const delay = Math.min(15000, 800 * Math.pow(2, Math.min(wsRetry++, 4))) + Math.random() * 300;
  wsTimer = setTimeout(() => {
    if (!document.hidden) connectWS();
  }, delay);
}

async function pollState() {
  // WS 通着就不轮询（省请求）；WS 断开时这里自动兜底
  if (wsOpen() || polling || document.hidden) return;
  polling = true;
  try {
    const s = await api.get('/api/state');
    pollFails = 0;
    setOffline(false);
    applyIncoming(s, 0.85);
  } catch (e) {
    pollFails += 1;
    if (pollFails >= 3) setOffline(true);
  }
  polling = false;
}

/* ---------------------------------------------------------------- 自测 */
async function runSelftest() {
  const log = [];
  const ok = (name, cond, extra) => {
    log.push((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : ` [${extra ?? ''}]`));
  };

  function at(r, c) {
    const [x, y] = view.xy(r, c);
    const rect = el.canvas.getBoundingClientRect();
    return [
      rect.left + (x * rect.width) / BOARD.W,
      rect.top + (y * rect.height) / BOARD.H,
    ];
  }
  function fire(type, r, c) {
    const [x, y] = at(r, c);
    el.canvas.dispatchEvent(new PointerEvent(type, {
      bubbles: true, cancelable: true, clientX: x, clientY: y,
      pointerId: 1, pointerType: 'mouse', isPrimary: true,
    }));
  }
  async function click(r, c) {
    fire('pointerdown', r, c);
    fire('pointerup', r, c);
    await sleep(220);
  }
  async function raw(path, body, room, client) {
    const url = `${path}?room=${room}&client=${client}`;
    const r = await fetch(url, body
      ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
      : { cache: 'no-store' });
    return r.json();
  }

  // 每次跑用新的房间号，免得被上次残留的座位影响
  const R1 = 'T' + Math.random().toString(36).slice(2, 6).toUpperCase();
  const R2 = 'T' + Math.random().toString(36).slice(2, 6).toUpperCase();

  try {
    ok('棋盘 15×15', BOARD.SIZE === 15);
    ok('坐标 H8 在中心', view.xy(7, 7)[0] === BOARD.W / 2);

    // 1. 双人：点一下落子
    await api.post('/api/new', { mode: 'pvp', level: '普通' });
    adopt(await api.get('/api/state'));
    await sleep(80);
    await click(7, 7);
    let st = await api.get('/api/state');
    const dbg = () => JSON.stringify({ toast: el.toast.textContent, mode: app.state.mode, players: app.state.players, you: app.state.you, turn: app.state.turn });
    ok('点击落子', st.history.length === 1 && st.board[7][7] === 1, dbg());
    ok('轮次切到白方', st.turn === 2, dbg());
    ok('记谱是 H8', st.history[0].text === 'H8');

    // 2. 点已有子的位置不落子
    await click(7, 7);
    st = await api.get('/api/state');
    ok('已有子的位置不重复落', st.history.length === 1);

    // 3. 白方落子
    await click(7, 8);
    st = await api.get('/api/state');
    ok('白方落子', st.history.length === 2 && st.board[7][8] === 2);
    ok('轮次回到黑方', st.turn === 1);

    // 4. 人机：电脑应手
    await api.post('/api/new', { mode: 'ai', level: '普通' });
    adopt(await api.get('/api/state'));
    await sleep(80);
    await click(7, 7);
    let waited = 0;
    while (waited < 8000) {
      const s = await api.get('/api/state');
      if (s.history.length >= 2) break;
      await sleep(150);
      waited += 150;
    }
    let aiState = await api.get('/api/state');
    ok('电脑应手', aiState.history.length === 2);
    ok('电脑执白', aiState.history[1].side === 2);
    ok('轮次回到人', aiState.turn === 1);

    // 5. 人机悔棋：退掉电脑和自己的各一手
    const undoRes = await api.post('/api/undo');
    ok('人机悔棋成功', undoRes.ok === true);
    aiState = await api.get('/api/state');
    ok('悔棋退回开局', aiState.history.length === 0 && aiState.turn === 1);

    // 6. 五连判胜（另一个房间，不打扰当前对局）
    await raw('/api/new', { mode: 'pvp', level: '普通' }, R1, 'a');
    const seq = [
      [7, 3], [0, 0], [7, 4], [0, 1], [7, 5], [0, 2], [7, 6], [0, 3], [7, 7],
    ];
    for (const [r, c] of seq) await raw('/api/move', { r, c }, R1, 'a');
    const winState = await raw('/api/state', null, R1, 'a');
    ok('五连判胜', winState.over === true && winState.winner === 1);
    ok('返回连子坐标', Array.isArray(winState.line) && winState.line.length === 5);
    ok('胜因正确', /五连/.test(winState.reason || ''));

    // 7. 双人悔棋：第一次免费，第二次要对方同意
    await raw('/api/new', { mode: 'pvp', level: '普通' }, R2, 'a');
    await raw('/api/state', null, R2, 'b');           // b 入座执白
    await raw('/api/move', { r: 7, c: 7 }, R2, 'a');
    await raw('/api/move', { r: 7, c: 8 }, R2, 'b');
    let u1 = await raw('/api/undo', {}, R2, 'a');
    ok('双人第一次悔棋免费', u1.ok === true && !u1.pending);
    let s2 = await raw('/api/state', null, R2, 'a');
    ok('第一次悔棋退了两手', s2.history.length === 0);

    await raw('/api/move', { r: 7, c: 7 }, R2, 'a');
    await raw('/api/move', { r: 8, c: 8 }, R2, 'b');
    let u2 = await raw('/api/undo', {}, R2, 'b');
    ok('第二次悔棋要对方同意', u2.ok === true && u2.pending === true);
    let s3 = await raw('/api/state', null, R2, 'a');
    ok('请求挂起时可见', !!s3.undoRequest && s3.undoRequest.by === 2);
    let u3 = await raw('/api/undo/respond', { accept: true }, R2, 'a');
    ok('对方同意后生效', u3.ok === true && u3.accepted === true);

    // 8. 观战不能落子
    await raw('/api/state', null, R2, 'c');
    let spec = await raw('/api/move', { r: 0, c: 0 }, R2, 'c');
    ok('观战者不能落子', spec.ok === false && /观战/.test(spec.error || ''));

    // 9. 轮询同步：直接调接口落子，前端能跟上
    await api.post('/api/new', { mode: 'pvp', level: '普通' });
    adopt(await api.get('/api/state'));
    const beforeRev = app.state.rev;
    await api.post('/api/move', { r: 7, c: 7 });
    await sleep(1400);
    ok('轮询同步到新的一手', app.state.rev > beforeRev && app.state.history.length === 1);

    // 10. 同一个局面被重复同步时，落子动画只能播一次
    await api.post('/api/new', { mode: 'pvp', level: '普通' });
    adopt(await api.get('/api/state'));
    await api.post('/api/move', { r: 7, c: 7 });
    const once = await api.get('/api/state');
    view.anims = [];
    adopt(once);
    const drops1 = view.anims.filter((a) => a.kind === 'drop').length;
    adopt(once);                                  // 轮询/响应撞在一起
    const drops2 = view.anims.filter((a) => a.kind === 'drop').length;
    ok('重复同步只落一次', drops1 === 1 && drops2 === 1, `${drops1}/${drops2}`);

    // 迟到的旧响应不能把棋盘倒回去（否则会"消失再落一次"）
    const staleState = { ...once, rev: once.rev - 5, history: [] };
    adopt(staleState);
    ok('迟到的旧状态被忽略', app.state.rev === once.rev && app.state.history.length === 1,
      `rev=${app.state.rev} hist=${app.state.history.length}`);

    // 11. 悔棋确认框
    const keep = app.state;
    app.state = { ...keep, you: 1, players: 2, undoRequest: { id: 1, by: 2, used: 1 } };
    handleUndoRequest();
    ok('对方请求悔棋时弹窗', el.undoModal.hidden === false);
    app.state = { ...keep, undoRequest: null };
    handleUndoRequest();
    ok('请求结束弹窗关闭', el.undoModal.hidden === true);
    app.state = keep;

    // 12. 音效开关
    ok('音效开关存在', !!el.soundBtn);
    const soundBefore = Sound.isEnabled();
    el.soundBtn.click();
    ok('音效可以关掉', Sound.isEnabled() === !soundBefore);
    el.soundBtn.click();
    ok('音效可以再打开', Sound.isEnabled() === soundBefore);

    const peakPlace = await Sound.testRender('place');
    const peakWhite = await Sound.testRender('place-white');
    const peakWin = await Sound.testRender('win');
    const peakUndo = await Sound.testRender('undo');
    ok('落子音效有声音', peakPlace > 0.02, peakPlace.toFixed(3));
    ok('白子音效有声音', peakWhite > 0.02, peakWhite.toFixed(3));
    ok('胜利音效有声音', peakWin > 0.02, peakWin.toFixed(3));
    ok('悔棋音效有声音', peakUndo > 0.02, peakUndo.toFixed(3));
    ok('音效不爆音', Math.max(peakPlace, peakWhite, peakWin, peakUndo) < 0.98,
      Math.max(peakPlace, peakWhite, peakWin, peakUndo).toFixed(3));
    log.push(`PEAKS 黑${peakPlace.toFixed(2)} 白${peakWhite.toFixed(2)} 胜${peakWin.toFixed(2)} 悔${peakUndo.toFixed(2)}`);

    // 13. 联机信息（只留房间码，房间功能对所有访客开放）
    ok('房主能看到联机信息', app.isHost === true && el.invite.hidden === false);
    ok('房间信息对所有访客可见', el.invite.hidden === false);
    ok('主页有「开个房间」按钮', !!document.getElementById('btn-createroom'));
    ok('首页没有「双人对战」按钮', !document.querySelector('[data-start="pvp"]'));
    ok('侧栏只显示房间码', el.roomCode.textContent === ROOM);
    ok('房间码旁有复制按钮', !!document.getElementById('btn-copyroom'));
    ok('侧栏不再有网址/局域网行', !document.getElementById('share-direct')
      && !document.getElementById('share-lan') && !document.getElementById('lan-row'));

    // 14. 结束后自动开下一局
    await api.post('/api/new', { mode: 'pvp', level: '普通' });
    adopt(await api.get('/api/state'));
    app.state = { ...app.state, over: true, winner: 1, reason: '黑方五连', history: [] };
    scheduleNextRound();
    await sleep(7000);
    const next = await api.get('/api/state');
    ok('结束后自动开下一局', next.over === false && next.history.length === 0);
  } catch (err) {
    log.push('FAIL 异常: ' + (err && err.message ? err.message : String(err)));
  }

  const div = document.createElement('div');
  div.id = 'test-log';
  div.textContent = 'TESTRESULT ' + log.join(' | ');
  document.body.appendChild(div);
  console.log(div.textContent);
}

/* ---------------------------------------------------------------- 演示 / 截图 */
async function playScripted(moves, opts = {}) {
  for (const [r, c] of moves) {
    await api.post('/api/move', { r, c });
    adopt(await api.get('/api/state'));
    if (opts.delay) await sleep(opts.delay);
  }
}

const DEMO_MOVES = [
  [4, 4], [4, 5], [5, 5], [5, 6], [6, 6], [6, 7], [7, 7], [7, 8],
];
const WIN_MOVE = [8, 8];

/* ---------------------------------------------------------------- 启动 */
(async function boot() {
  const params = new URLSearchParams(location.search);

  // 谁算房主：本机打开 / ?host=1 / ?host=0 强制访客
  const onThisMachine = ['127.0.0.1', 'localhost', '::1', '[::1]'].includes(location.hostname);
  if (params.get('host') === '1') localStorage.setItem('gomoku-host', '1');
  if (params.get('host') === '0') localStorage.removeItem('gomoku-host');
  app.isHost = params.get('host') === '0'
    ? false
    : (onThisMachine || localStorage.getItem('gomoku-host') === '1');

  // 房号：URL 里带了就是"被邀请进来的"；没带就自动生成一个
  const invited = !!(params.get('room') || '').trim();
  let code = (params.get('room') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  if (!code) {
    code = makeRoomCode();
    params.set('room', code);
    history.replaceState(null, '', '?' + params.toString());
  }
  ROOM = code;
  el.roomCode.textContent = code;
  // 房间码 / 邀请链接对所有人开放（不再只给房主看）
  if (el.invite) el.invite.hidden = false;

  if (params.get('shot') || params.get('static')) {
    document.body.classList.add('no-anim');
    app.freezeRound = true;
  }
  if (params.get('over')) app.freezeRound = true;

  if (params.get('probe')) {
    setTimeout(() => {
      const c = el.canvas;
      const r = c.getBoundingClientRect();
      const appRect = document.getElementById('app').getBoundingClientRect();
      const d = document.createElement('div');
      d.id = 'probe';
      d.textContent = `PROBE vw=${innerWidth} vh=${innerHeight} `
        + `canvasCss=${r.width.toFixed(0)}x${r.height.toFixed(0)} `
        + `canvasAttr=${c.width}x${c.height} dpr=${devicePixelRatio} `
        + `app=${appRect.width.toFixed(0)}x${appRect.height.toFixed(0)}`;
      document.body.appendChild(d);
    }, 600);
  }

  const state = await api.get('/api/state');
  // 从「开个房间 / 加入对局」进来的对局固定双人模式
  if (params.get('mode') === 'pvp') {
    app.lockedPvp = true;
    if (state.mode !== 'pvp') {
      const res = await api.post('/api/settings', { mode: 'pvp' });
      if (res && res.ok) Object.assign(state, res.state);
    }
  }
  app.level = state.level;
  adopt(state);

  // 刷新时如果上一局正轮到电脑（人机模式），把它没走完的那步补上
  if (state.mode === 'ai' && !state.over && state.turn === 2 && (state.players || 1) < 2) {
    setTimeout(aiTurn, 400);
  }

  if (invited) enterGame();

  // 开新房间：主页「开个房间」和侧栏「换」都走这里（房间固定双人）
  function newRoom() {
    const next = new URLSearchParams(location.search);
    next.set('room', makeRoomCode());
    next.set('mode', 'pvp');
    location.search = next.toString();
  }
  const newRoomBtn = document.getElementById('btn-newroom');
  if (newRoomBtn) newRoomBtn.addEventListener('click', newRoom);
  const createRoomBtn = document.getElementById('btn-createroom');
  if (createRoomBtn) createRoomBtn.addEventListener('click', newRoom);

  // 复制房间码（新 API 失败时退回隐藏 textarea + execCommand，兼容老浏览器）
  const copyRoomBtn = document.getElementById('btn-copyroom');
  if (copyRoomBtn) {
    copyRoomBtn.addEventListener('click', async () => {
      const text = (el.roomCode && el.roomCode.textContent || ROOM).trim();
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(text);
        } else {
          const ta = document.createElement('textarea');
          ta.value = text;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          document.body.removeChild(ta);
        }
        toast(`房间码已复制：${text}`);
      } catch (e) {
        toast('复制失败，手动记一下房间码');
      }
    });
  }

  // 每 900ms 同步一次（WS 断开时的兜底）；WS 通了会跳过轮询
  setInterval(pollState, 900);
  // 无头自测用 ?nows=1 走纯轮询：长连接会让 Chrome 的虚拟时间停住，普通浏览器不受影响
  const probeWS = params.get('wsprobe') === '1';
  const noWS = params.get('nows') === '1' || probeWS;
  if (!noWS) {
    connectWS();
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && !wsOpen()) connectWS();
    });
  }

  // WS 探针：真浏览器连一次 /ws，收到首帧状态就关掉并留个标记，供无头自测检查
  if (probeWS) {
    const mark = (text) => {
      const d = document.createElement('div');
      d.id = 'ws-probe';
      d.textContent = 'WSPROBE ' + text;
      document.body.appendChild(d);
    };
    const url = wsURL();
    if (!url) {
      mark('error no-url');
    } else {
      const probe = new WebSocket(url);
      probe.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg.t === 'state' && msg.state) {
            mark(`ok rev=${msg.rev} board=${(msg.state.board || []).length} you=${msg.state.you}`);
            probe.close();
          }
        } catch (e) {
          mark('error bad-json');
        }
      };
      probe.onerror = () => mark('error connect');
    }
  }

  if (params.get('start')) {
    await startGame(params.get('start'));
  }
  if (params.get('test')) {
    await runSelftest();
  }
  if (params.get('demo') || params.get('shot')) {
    await startGame('pvp');
    await playScripted(DEMO_MOVES, { delay: params.get('shot') ? 0 : 60 });
    if (params.get('over')) {
      await playScripted([WIN_MOVE]);
    }
  }
  if (params.get('over') && !params.get('demo') && !params.get('shot')) {
    app.state = { ...app.state, over: true, winner: 1, reason: '黑方五连', line: [[4, 4], [5, 5], [6, 6], [7, 7], [8, 8]] };
    view.setState({ over: true, winner: 1, line: app.state.line });
    renderStatus();
  }
})();
