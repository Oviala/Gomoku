define config.name = "夏日尾声"
define build.name = "NatsuNoOwari"
