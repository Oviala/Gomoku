#!/bin/bash
# 双击这个文件启动五子棋（macOS）
cd "$(dirname "$0")" || exit 1
PORT=8766

if curl -s -o /dev/null --max-time 1 "http://127.0.0.1:$PORT/"; then
  open "http://127.0.0.1:$PORT/"
  exit 0
fi

if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display dialog "需要先安装 Python 3\n到 python.org 下载安装后，再双击一次" buttons {"好"}'
  exit 1
fi

nohup python3 server.py > /tmp/gomoku-offline.log 2>&1 &
for _ in $(seq 1 40); do
  curl -s -o /dev/null --max-time 1 "http://127.0.0.1:$PORT/" && break
  sleep 0.25
done
open "http://127.0.0.1:$PORT/"
