#!/usr/bin/env python3
"""本地 Web 服务：静态文件 + 五子棋 JSON API。

只依赖标准库。规则与 AI 复用 gmk/ 包，前端只负责画。
启动：python3 server.py（默认 8766，可用 GOMOKU_PORT 改）
"""

from __future__ import annotations

import json
import mimetypes
import os
import socket
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from gmk import ai
from gmk.board import BLACK, WHITE, Board, other
from gmk.notation import point_text
from gmk.rules import is_draw, winning_line

ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "web"
PORT = int(os.environ.get("GOMOKU_PORT", "8766"))

# 名称 -> 搜索参数。margin 越大越"随性"，也就越弱。
LEVELS = {
    "简单": dict(depth=2, time_limit=0.8, margin=2500, width=8),
    "普通": dict(depth=3, time_limit=1.5, margin=700, width=10),
    "困难": dict(depth=4, time_limit=2.5, margin=90, width=12),
}


class Session:
    """单局状态。HTTP 是多线程的，所以对外方法都加锁。"""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.clients: dict[str, float] = {}     # 客户端 id -> 首次进入时间
        self.reset("ai", "普通")

    # ------------------------------------------------------------ 生命周期
    def reset(self, mode: str = "ai", level: str = "普通") -> None:
        self.board = Board()
        self.turn = BLACK
        self.mode = "pvp" if mode == "pvp" else "ai"
        self.level = level if level in LEVELS else "普通"
        self.history: list[tuple[int, int, int]] = []      # (r, c, side)
        self.last: tuple[int, int] | None = None
        self.line: list[tuple[int, int]] | None = None
        self.winner: int | None = None
        self.reason = ""
        self.over = False
        self.undo_used = 0
        self.undo_limit = 3
        self.undo_request: dict | None = None
        self.undo_seq = 0
        # 单调递增：新局也要 +1，否则另一端的轮询发现不了
        self.rev = getattr(self, "rev", -1) + 1

    # ------------------------------------------------------------ 座位
    def touch(self, client: str | None) -> None:
        """记录一个客户端；第二个人进来时自动切到双人对战。"""
        if not client:
            return
        with self.lock:
            if client in self.clients:
                return
            self.clients[client] = time.time()
            if len(self.clients) > 8:                 # 只保留最早的几个
                keep = sorted(self.clients.items(), key=lambda kv: kv[1])[:8]
                self.clients = dict(keep)
            if len(self.clients) >= 2 and self.mode == "ai":
                self.mode = "pvp"                     # 有人来了就别跟电脑下了
            self.rev += 1

    def side_of(self, client: str | None) -> int | None:
        """最早进来的执黑（先手），第二个执白，其余观战。"""
        if not client or client not in self.clients:
            return None
        order = sorted(self.clients.items(), key=lambda kv: kv[1])
        for index, (cid, _ts) in enumerate(order[:2]):
            if cid == client:
                return BLACK if index == 0 else WHITE
        return None

    def player_count(self) -> int:
        return min(2, len(self.clients))

    # ------------------------------------------------------------ 序列化
    def snapshot(self, client: str | None = None) -> dict:
        return {
            "board": [row[:] for row in self.board.grid],
            "turn": self.turn,
            "mode": self.mode,
            "level": self.level,
            "last": list(self.last) if self.last else None,
            "line": [list(p) for p in self.line] if self.line else None,
            "over": self.over,
            "winner": self.winner,
            "reason": self.reason,
            "status": "over" if self.over else "playing",
            "rev": self.rev,
            "you": self.side_of(client),
            "players": self.player_count(),
            "undoUsed": self.undo_used,
            "undoLimit": self.undo_limit,
            "undoRequest": self.undo_request,
            "moves": self.board.size * self.board.size - self.board.count,
            "history": [
                {"text": point_text(r, c), "side": side}
                for r, c, side in self.history
            ],
        }

    # ------------------------------------------------------------ 操作
    def settings(self, mode: str | None, level: str | None) -> dict:
        with self.lock:
            if mode in ("ai", "pvp"):
                self.mode = mode
            if level in LEVELS:
                self.level = level
            self.rev += 1
            return self.snapshot()

    def make_move(self, r: int, c: int, client: str | None = None) -> dict:
        with self.lock:
            if self.over:
                return {"ok": False, "error": "对局已经结束"}
            if not self.board.inside(r, c):
                return {"ok": False, "error": "落点不在棋盘上"}

            my_side = self.side_of(client)
            if self.player_count() >= 2 and my_side is None:
                return {"ok": False, "error": "你在观战，不能落子"}
            if self.player_count() >= 2 and my_side is not None and my_side != self.turn:
                who = "黑方" if self.turn == BLACK else "白方"
                return {"ok": False, "error": f"还没轮到你，现在是{who}"}
            if not self.board.is_empty(r, c):
                return {"ok": False, "error": "这里已经有子了"}

            return self._apply_move(r, c)

    def _apply_move(self, r: int, c: int) -> dict:
        side = self.turn
        self.board.place(r, c, side)
        self.history.append((r, c, side))
        self.last = (r, c)
        self.turn = other(side)
        self.rev += 1

        line = winning_line(self.board, r, c)
        if line is not None:
            self.over = True
            self.winner = side
            self.reason = f"{'黑方' if side == BLACK else '白方'}五连"
            self.line = line
        elif is_draw(self.board):
            self.over = True
            self.winner = 0
            self.reason = "棋盘下满，和棋"
            self.line = None

        return {
            "ok": True,
            "point": [r, c],
            "side": side,
            "state": self.snapshot(),
        }

    def ai_move(self) -> dict:
        with self.lock:
            if self.over or self.mode != "ai":
                return {"ok": False, "error": "现在不该电脑走"}
            if self.turn != WHITE:
                return {"ok": False, "error": "现在不该电脑走"}

            move = ai.best_move(self.board, WHITE, **LEVELS[self.level])
            if move is None:
                self.over = True
                self.winner = 0
                self.reason = "棋盘下满，和棋"
                return {"ok": True, "move": None, "state": self.snapshot()}

            r, c = move
            result = self._apply_move(r, c)
            return {
                "ok": True,
                "move": [r, c],
                "state": result["state"],
            }

    # ------------------------------------------------------------ 悔棋
    def _steps_for(self, side: int | None) -> int:
        """悔棋要退几步：退回到这个人上一次落子之前。"""
        if not self.history:
            return 0
        if side is None:
            return 1
        if self.history[-1][2] == side:
            return 1
        return min(2, len(self.history))

    def _pop(self, steps: int, client: str | None) -> None:
        for _ in range(steps):
            r, c, side = self.history.pop()
            self.board.remove(r, c)
            self.turn = side
        self.last = (self.history[-1][0], self.history[-1][1]) if self.history else None
        self.over = False
        self.winner = None
        self.reason = ""
        self.line = None

    def undo(self, client: str | None = None) -> dict:
        with self.lock:
            if not self.history:
                return {"ok": False, "error": "还没有落子，没得悔"}

            # 人机模式：退一步，电脑那步也一起退掉
            if self.mode != "pvp":
                steps = 2 if self.history[-1][2] == WHITE else 1
                self._pop(min(steps, len(self.history)), client)
                self.rev += 1
                return {"ok": True, "state": self.snapshot(client)}

            # 双人模式
            side = self.side_of(client)
            if self.undo_request is not None:
                return {"ok": False, "error": "已经有一个悔棋请求在等回应"}
            if self.undo_used >= self.undo_limit:
                return {"ok": False, "error": f"本局悔棋次数用完了（{self.undo_limit} 次）"}

            # 第一次免费，之后要对方同意
            if self.undo_used == 0:
                self._pop(self._steps_for(side), client)
                self.undo_used += 1
                self.rev += 1
                return {"ok": True, "state": self.snapshot(client)}

            self.undo_seq += 1
            self.undo_request = {"id": self.undo_seq, "by": side, "used": self.undo_used}
            self.rev += 1
            return {"ok": True, "pending": True, "state": self.snapshot(client)}

    def respond_undo(self, client: str | None, accept: bool) -> dict:
        with self.lock:
            req = self.undo_request
            if req is None:
                return {"ok": False, "error": "没有待处理的悔棋请求"}

            side = self.side_of(client)
            if side is None:
                return {"ok": False, "error": "观战不能操作"}
            if side == req["by"]:
                return {"ok": False, "error": "不能自己同意自己"}

            if accept:
                self._pop(self._steps_for(req["by"]), client)
                self.undo_used += 1

            self.undo_request = None
            self.rev += 1
            return {"ok": True, "accepted": accept, "state": self.snapshot(client)}


# ---------------------------------------------------------------- 房间
ROOMS: dict[str, Session] = {}
ROOMS_LOCK = threading.Lock()
ROOM_TTL = 6 * 3600          # 6 小时没人用的房间自动回收
STORE_FILE = ROOT / "rooms_state.json"
TUNNEL_URL_FILE = Path("/tmp/gomoku-tunnel-url.txt")
TUNNEL_FRESH_SECONDS = 90     # 隧道脚本每 5 秒心跳一次；超过这个时间没心跳就当是死链
PUBLIC_URL_FILE = ROOT / "public_url.txt"    # 固定地址：配一次，之后一直用它


def fixed_public_url() -> str | None:
    """固定公网地址：环境变量 GOMOKU_PUBLIC_URL 优先，其次是项目根目录的 public_url.txt。

    适合 Cloudflare 命名隧道 / 自己的服务器 / ngrok 静态域名 —— 这些地址不会变，
    不需要隧道脚本写心跳文件。
    """
    value = os.environ.get("GOMOKU_PUBLIC_URL", "").strip()
    if not value:
        try:
            value = PUBLIC_URL_FILE.read_text(encoding="utf-8").strip()
        except OSError:
            return None
    if not value.startswith(("http://", "https://")):
        return None
    return value.rstrip("/")


def tunnel_url() -> str | None:
    """读隧道脚本写下的当前公网地址。地址会随隧道重启而变，所以只认"还活着"的。

    隧道被 Cloudflare 回收后，进程往往不退出、只会在日志里刷错，
    于是地址文件会留在磁盘上变成死链。这里用文件的修改时间当心跳：
    隧道脚本每 5 秒 touch 一次，超过 90 秒没动就不给前端显示。
    """
    try:
        value = TUNNEL_URL_FILE.read_text(encoding="utf-8").strip()
        age = time.time() - TUNNEL_URL_FILE.stat().st_mtime
    except OSError:
        return None
    if not value.startswith("http"):
        return None
    if age > TUNNEL_FRESH_SECONDS:
        return None
    return value


def normalize_room(code: str | None) -> str:
    code = (code or "").strip().upper()
    code = "".join(ch for ch in code if ch.isalnum() and ch.isascii())
    return code[:6] or "MAIN"


def peek_room(code: str | None) -> Session | None:
    with ROOMS_LOCK:
        return ROOMS.get(normalize_room(code))


def get_room(code: str | None) -> Session:
    code = normalize_room(code)
    with ROOMS_LOCK:
        session = ROOMS.get(code)
        if session is None:
            session = Session()
            ROOMS[code] = session
        session.touched = time.time()

        now = time.time()
        for key in [k for k, v in ROOMS.items()
                    if now - getattr(v, "touched", now) > ROOM_TTL]:
            if key != code:
                del ROOMS[key]
        return session


def _session_to_dict(s: Session) -> dict:
    return {
        "mode": s.mode,
        "level": s.level,
        "board": [row[:] for row in s.board.grid],
        "turn": s.turn,
        "history": [list(item) for item in s.history],
        "last": list(s.last) if s.last else None,
        "line": [list(p) for p in s.line] if s.line else None,
        "over": s.over,
        "winner": s.winner,
        "reason": s.reason,
        "rev": s.rev,
        "clients": dict(s.clients),
    }


def _session_from_dict(d: dict) -> Session:
    s = Session()
    s.mode = d.get("mode", "ai")
    s.level = d.get("level", "普通")
    s.board = Board()
    for r, row in enumerate(d.get("board", [])):
        for c, value in enumerate(row):
            if value:
                s.board.place(r, c, int(value))
    s.turn = int(d.get("turn", BLACK))
    s.history = [(int(r), int(c), int(side)) for r, c, side in d.get("history", [])]
    last = d.get("last")
    s.last = (int(last[0]), int(last[1])) if last else None
    line = d.get("line")
    s.line = [(int(p[0]), int(p[1])) for p in line] if line else None
    s.over = bool(d.get("over"))
    s.winner = d.get("winner")
    s.reason = d.get("reason", "")
    s.rev = int(d.get("rev", 0))
    s.clients = dict(d.get("clients", {}))
    s.touched = time.time()
    return s


def save_rooms() -> None:
    with ROOMS_LOCK:
        payload = {code: _session_to_dict(sess) for code, sess in ROOMS.items()}
    try:
        STORE_FILE.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def load_rooms() -> None:
    try:
        raw = json.loads(STORE_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    for code, data in raw.items():
        try:
            ROOMS[code] = _session_from_dict(data)
        except (KeyError, TypeError, ValueError):
            continue


class DualStackServer(ThreadingHTTPServer):
    """同时监听 IPv4 和 IPv6，外网可以直接用 IPv6 连进来。"""

    address_family = socket.AF_INET6
    daemon_threads = True

    def server_bind(self):
        try:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except (AttributeError, OSError):
            pass
        super().server_bind()


_IPV6_CACHE: dict = {"at": 0.0, "value": None}


def global_ipv6() -> str | None:
    """取一个全局 IPv6 地址（排除临时地址和链路本地地址）。

    前端每 10 秒会拉一次 /api/info 校正链接，这里缓存 60 秒，别每次都起 ifconfig。
    """
    now = time.time()
    if now - _IPV6_CACHE["at"] < 60:
        return _IPV6_CACHE["value"]

    try:
        out = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=3).stdout
    except (OSError, subprocess.SubprocessError):
        return None

    for line in out.splitlines():
        line = line.strip()
        if not line.startswith("inet6 "):
            continue
        if "temporary" in line or line.startswith("inet6 fe80"):
            continue
        addr = line.split()[1].split("%")[0]
        if addr.startswith("2001:") or addr.startswith("240") or addr.startswith("2a"):
            _IPV6_CACHE.update(at=now, value=addr)
            return addr

    _IPV6_CACHE.update(at=now, value=None)
    return None


def lan_ip() -> str:
    """猜一个局域网地址，用于告诉朋友连哪个。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


class Handler(BaseHTTPRequestHandler):
    server_version = "Gomoku/1.0"

    # ------------------------------------------------------------ 工具
    def log_message(self, fmt: str, *args) -> None:   # 静音访问日志
        pass

    def _send_json(self, payload: dict, code: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path) -> None:
        if not path.is_file():
            self.send_error(404, "Not Found")
            return
        data = path.read_bytes()
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if path.suffix == ".js":
            ctype = "text/javascript; charset=utf-8"
        elif path.suffix == ".css":
            ctype = "text/css; charset=utf-8"
        elif path.suffix == ".html":
            ctype = "text/html; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    # ------------------------------------------------------------ 路由
    def _query(self) -> dict:
        return parse_qs(urlparse(self.path).query)

    def _room(self) -> Session:
        query = self._query()
        return get_room((query.get("room") or ["MAIN"])[0])

    def _client(self) -> str | None:
        query = self._query()
        value = (query.get("client") or [""])[0]
        return value[:40] or None

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/state":
            room = self._room()
            client = self._client()
            room.touch(client)
            self._send_json(room.snapshot(client))
            return
        if path == "/api/room":
            query = self._query()
            code = normalize_room((query.get("code") or [""])[0])
            sess = peek_room(code)
            self._send_json({
                "ok": True,
                "code": code,
                "exists": sess is not None,
                "players": sess.player_count() if sess else 0,
                "mode": sess.mode if sess else None,
                "over": sess.over if sess else None,
            })
            return
        if path == "/api/health":
            self._send_json({"ok": True, "mode": "server", "room": "any"})
            return
        if path == "/api/info":
            session = self._room()
            session.touch(self._client())
            query = self._query()
            room_code = normalize_room((query.get("room") or ["MAIN"])[0])
            v6 = global_ipv6()
            fixed = fixed_public_url()
            tunnel = tunnel_url()
            public = fixed or tunnel
            self._send_json({
                "ok": True,
                "lan": f"http://{lan_ip()}:{PORT}/",
                "room": room_code,
                "link": f"http://{lan_ip()}:{PORT}/?room={room_code}",
                "v6": v6,
                "v6link": f"http://[{v6}]:{PORT}/?room={room_code}" if v6 else None,
                "public": public,
                "publicLink": f"{public}/?room={room_code}" if public else None,
                "publicFixed": bool(fixed),
                "tunnel": tunnel,
                "rev": session.rev,
                "you": session.side_of(self._client()),
                "players": session.player_count(),
            })
            return
        if path in ("/", "/index.html"):
            self._send_file(WEB_DIR / "index.html")
            return
        self._send_file(WEB_DIR / path.lstrip("/"))

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        data = self._body()
        room = self._room()
        client = self._client()
        room.touch(client)          # 发请求的人算在场，座位按先来后到排

        try:
            if path == "/api/new":
                room.reset(data.get("mode", "ai"), data.get("level", "普通"))
                save_rooms()
                self._send_json({"ok": True, "state": room.snapshot(client)})
                return

            if path == "/api/settings":
                state = room.settings(data.get("mode"), data.get("level"))
                save_rooms()
                self._send_json({"ok": True, "state": state})
                return

            if path == "/api/move":
                result = room.make_move(int(data["r"]), int(data["c"]), client)
                if result.get("ok"):
                    save_rooms()
                self._send_json(result)
                return

            if path == "/api/ai":
                result = room.ai_move()
                if result.get("ok"):
                    save_rooms()
                self._send_json(result)
                return

            if path == "/api/undo/respond":
                result = room.respond_undo(client, bool(data.get("accept")))
                save_rooms()
                self._send_json(result)
                return

            if path == "/api/undo":
                result = room.undo(client)
                if result.get("ok"):
                    save_rooms()
                self._send_json(result)
                return
        except (KeyError, TypeError, ValueError) as exc:
            self._send_json({"ok": False, "error": f"请求参数有误: {exc}"}, 400)
            return

        self._send_json({"ok": False, "error": "未知接口"}, 404)


def serve(port: int = PORT) -> None:
    load_rooms()
    httpd = DualStackServer(("::", port), Handler)
    print(f"本机:     http://127.0.0.1:{port}/")
    print(f"局域网:   http://{lan_ip()}:{port}/   <- 同一个 Wi-Fi")
    v6 = global_ipv6()
    if v6:
        print(f"公网 IPv6: http://[{v6}]:{port}/   <- 不同网络时，对方有 IPv6 就能直接连")
    else:
        print("公网 IPv6: 没检测到，跨网络需要内网穿透（见 README）")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    serve()
