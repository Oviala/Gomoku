# 夏日尾声 · Ren'Py 演示
define config.name = "夏日尾声"
define sora = Character("橘 そら", color="#f0c9a0")
define yuki = Character("雪村 ゆき", color="#bcd7ff")
define narrator = Character(None)

# 序章 · 蝉时雨
label start:
    scene bg_dusk
    play music "bgm_dusk"
    "蝉声在黄昏里慢慢退潮。"
    "河堤上只剩下我们两个人的影子。"
    show sora normal at center
    sora "……你看，今年的蝉，好像比去年叫得早一点。"
    sora "你说，夏天是不是也会累？"
    "她问得很轻，像怕惊动什么。"
    menu:
        "附和一句「是啊」":
            sora "嗯。那就早点回去，别中暑。"
            "她笑起来的时候，眼睛弯成了很浅的月牙。"
            jump chapter_two
        "沉默地望向天空":
            "你什么也没说。风把她的发梢吹起来一点。"
            sora "……不说话也可以。"
            sora "反正我也只是随口问问。"
            jump chapter_two
        "把汽水递给她":
            show yuki normal at right
            yuki "诶，那我也要一瓶！"
            sora "你从哪冒出来的？"
            yuki "一直都在呀。"
            hide yuki
            sora "……真是的。"
            jump chapter_two

# 第二章 · 窗边
label chapter_two:
    scene bg_classroom
    hide sora
    "教室的窗把黄昏切成一条一条。"
    show sora normal at center
    "她把没做完的习题推到一边，趴在桌上看着窗外。"
    sora "明天，还来吗？"
    menu:
        "会来":
            sora "那说好了。"
            "她伸出小指，像是在确认一件很重要的事。"
            jump ending
        "大概吧":
            sora "大概……也行。"
            "她没有再追问，只是把下巴埋进手臂里。"
            jump ending

# 终章 · 夏日尾声
label ending:
    "夏天就这样，被我们一人一句地过完了。"
    hide sora
    "后来我常常想起那个下午——"
    "想起蝉声、汽水，和她没有说完的那句话。"
    "（演示结束 · 感谢游玩 REALWORLDS）"
    return
