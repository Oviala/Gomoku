"""五子棋（Gomoku）纯逻辑包：棋盘、规则、记谱、电脑对手。

不依赖任何 UI 或网络库，服务端与测试都直接用它。
"""

__all__ = ["board", "rules", "notation", "ai"]
