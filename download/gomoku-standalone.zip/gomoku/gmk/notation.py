"""坐标记谱：列 A–P（跳过容易和 1 混的 I），行 1–15 从下到上。

例如天元是 H8，左上角是 A15，右上角是 P15。
"""

from __future__ import annotations

from .board import SIZE

COLS = "ABCDEFGHJKLMNOP"


def point_text(r: int, c: int, size: int = SIZE) -> str:
    if not (0 <= c < len(COLS)):
        raise ValueError(f"列超出范围: {c}")
    if not (0 <= r < size):
        raise ValueError(f"行超出范围: {r}")
    return f"{COLS[c]}{size - r}"


def parse_point(text: str, size: int = SIZE) -> tuple[int, int]:
    text = (text or "").strip().upper()
    if len(text) < 2:
        raise ValueError(f"坐标不合法: {text!r}")
    c = COLS.find(text[0])
    if c < 0:
        raise ValueError(f"坐标不合法: {text!r}")
    row = int(text[1:])
    if not 1 <= row <= size:
        raise ValueError(f"坐标不合法: {text!r}")
    return size - row, c
