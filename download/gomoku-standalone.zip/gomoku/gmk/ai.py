"""五子棋电脑对手：Negamax + Alpha-Beta，评估是增量算的。

评估思路（不写一堆棋型模板）：
    一条线上每个连续 5 格窗口，只要窗口里没有对方棋子，就按自己棋子的
    数量加分：0/1/12/260/8000/一千万。
    于是活四 = 两个"4 子窗口"、冲四 = 一个；活三 = 两个"3 子窗口"、
    眠三 = 一个。活/冲、活/眠自然就分开了。

搜索思路：
    - 候选点只取"已有棋子周围两格"的空点，按局部棋型排序后取前 N 个
    - 落子/悔棋只重算经过它的那几条线上的窗口（增量，很快）
    - 根节点先处理"我能成五"和"必须堵五"，剩下的交给迭代加深
    - 最后在"最优附近 margin 分以内"随机挑一个 —— 难度就靠
      depth / width / margin 三个旋钮调，既不会呆，也不会步步最优
"""

from __future__ import annotations

import heapq
import random
import time

from .board import BLACK, DIRS, EMPTY, WHITE, Board, other
from .rules import winning_points

WIN_SCORE = 10_000_000
INF = 1 << 30

# 5 格窗口里自己的子数 -> 权重
WINDOW = (0, 1, 12, 260, 8000, WIN_SCORE)

# 候选点排序：假设落子后能连成 n 子（含两端开放程度）的权重
SHAPE = (0, 1, 10, 120, 3000, 100_000)

DEFENSE = 1.15          # 防守比进攻稍重一点，先不死
CENTER_BONUS = 0.4      # 越靠中心越优先，避免开局乱飘


class _Timeout(Exception):
    """搜索超过时间上限。"""


def _all_lines(size: int):
    """棋盘上所有长度 >= 5 的线：15 横、15 竖、两条斜各 21 条。"""
    for r in range(size):
        yield [(r, c) for c in range(size)]
    for c in range(size):
        yield [(r, c) for r in range(size)]

    for c0 in range(size):                       # 正斜 "\"
        cells = []
        r, c = 0, c0
        while r < size and c < size:
            cells.append((r, c))
            r += 1
            c += 1
        if len(cells) >= 5:
            yield cells
    for r0 in range(1, size):
        cells = []
        r, c = r0, 0
        while r < size and c < size:
            cells.append((r, c))
            r += 1
            c += 1
        if len(cells) >= 5:
            yield cells

    for c0 in range(size):                       # 反斜 "/"
        cells = []
        r, c = 0, c0
        while r < size and c >= 0:
            cells.append((r, c))
            r += 1
            c -= 1
        if len(cells) >= 5:
            yield cells
    for r0 in range(1, size):
        cells = []
        r, c = r0, size - 1
        while r < size and c >= 0:
            cells.append((r, c))
            r += 1
            c -= 1
        if len(cells) >= 5:
            yield cells


class Scorer:
    """增量棋型分：落子 / 悔棋时只更新受影响的窗口。"""

    def __init__(self, board: Board) -> None:
        self.board = board
        self.scores = {BLACK: 0, WHITE: 0}
        # 棋盘可能摆着子（搜索时一直是中局局面），先按现状算一遍
        for cells in _all_lines(board.size):
            for side in (BLACK, WHITE):
                self.scores[side] += self._line_score(cells, side, board.grid)

    @staticmethod
    def _line_score(cells: list[tuple[int, int]], side: int, grid) -> int:
        total = 0
        for i in range(len(cells) - 4):
            total += Scorer._window_score(cells[i:i + 5], side, grid)
        return total

    @staticmethod
    def _window_score(window: list[tuple[int, int]], side: int, grid) -> int:
        own = 0
        for r, c in window:
            value = grid[r][c]
            if value == side:
                own += 1
            elif value != EMPTY:
                return 0
        return WINDOW[own]

    def place(self, r: int, c: int, side: int) -> None:
        self._apply(r, c, side)

    def remove(self, r: int, c: int) -> None:
        self._apply(r, c, EMPTY)

    def _apply(self, r: int, c: int, side: int) -> None:
        board = self.board
        grid = board.grid
        windows: list[list[tuple[int, int]]] = []
        for dr, dc in DIRS:
            cells = board.line_cells(r, c, dr, dc)
            index = cells.index((r, c))
            lo = max(0, index - 4)
            hi = min(index, len(cells) - 5)
            for start in range(lo, hi + 1):
                windows.append(cells[start:start + 5])

        before = [
            (self._window_score(w, BLACK, grid), self._window_score(w, WHITE, grid))
            for w in windows
        ]

        if side == EMPTY:
            board.remove(r, c)
        else:
            board.place(r, c, side)

        for i, window in enumerate(windows):
            self.scores[BLACK] += self._window_score(window, BLACK, grid) - before[i][0]
            self.scores[WHITE] += self._window_score(window, WHITE, grid) - before[i][1]

    def value(self, side: int) -> int:
        mine = self.scores[side]
        theirs = self.scores[other(side)]
        return mine - int(theirs * DEFENSE)


def _shape(board: Board, r: int, c: int, dr: int, dc: int, side: int) -> tuple[int, int]:
    """假设 side 落在 (r, c)，这个方向上能连成几子、两端有几头是空的。"""
    grid = board.grid
    size = board.size
    count = 1
    open_ends = 0
    for sign in (1, -1):
        rr, cc = r + sign * dr, c + sign * dc
        while 0 <= rr < size and 0 <= cc < size and grid[rr][cc] == side:
            count += 1
            rr += sign * dr
            cc += sign * dc
        if 0 <= rr < size and 0 <= cc < size and grid[rr][cc] == EMPTY:
            open_ends += 1
    return count, open_ends


def _attack(board: Board, r: int, c: int, side: int) -> int:
    total = 0.0
    for dr, dc in DIRS:
        count, ends = _shape(board, r, c, dr, dc, side)
        total += SHAPE[min(count, 5)] * (1 + 0.6 * ends)
    return int(total)


def _point_value(board: Board, r: int, c: int, side: int) -> float:
    """排序用：这一手对我多好 + 对对手多好（挡住他）。"""
    return _attack(board, r, c, side) + _attack(board, r, c, other(side)) * 0.9


class _Search:
    def __init__(self, board: Board, deadline: float, width: int) -> None:
        self.board = board
        self.deadline = deadline
        self.width = width
        self.scorer = Scorer(board)
        self.nodes = 0

    # ------------------------------------------------------------ 候选
    def ordered_moves(self, side: int, limit: int) -> list[tuple[int, int]]:
        board = self.board
        center = (board.size - 1) / 2
        scored: list[tuple[float, int, int]] = []
        for r, c in board.candidates():
            value = _point_value(board, r, c, side)
            value += (6 - max(abs(r - center), abs(c - center))) * CENTER_BONUS
            scored.append((value, r, c))
        top = heapq.nlargest(limit, scored)
        # nlargest 对同分是任意顺序，固定一下，保证可复现
        top.sort(key=lambda item: (-item[0], item[1], item[2]))
        return [(r, c) for _v, r, c in top]

    # ------------------------------------------------------------ 搜索
    def negamax(self, side: int, depth: int, alpha: int, beta: int, ply: int) -> int:
        self.nodes += 1
        if (self.nodes & 127) == 0 and time.monotonic() > self.deadline:
            raise _Timeout

        if depth <= 0:
            return self._leaf_value(side, ply)

        moves = self.ordered_moves(side, self.width)
        if not moves:
            return 0

        best = -INF
        for r, c in moves:
            self.scorer.place(r, c, side)
            if self.board.longest_run(r, c) >= 5:
                self.scorer.remove(r, c)
                return WIN_SCORE - ply
            value = -self.negamax(other(side), depth - 1, -beta, -alpha, ply + 1)
            self.scorer.remove(r, c)

            if value > best:
                best = value
                if value > alpha:
                    alpha = value
                    if alpha >= beta:
                        break
        return best

    def _leaf_value(self, side: int, ply: int) -> int:
        """叶子局面：先看"下一手能不能成五"，再看对方有没有冲四。

        不做这两件事的话，评估函数分不清"轮到谁"：
        双方各有一个活四时，它会以为局面五五开，其实轮到谁谁赢。
        """
        if winning_points(self.board, side):
            return WIN_SCORE - ply
        threats = winning_points(self.board, other(side))
        if len(threats) >= 2:
            return -WIN_SCORE + ply            # 双四，挡不住了
        if len(threats) == 1:
            r, c = threats[0]
            self.scorer.place(r, c, side)      # 只能先堵
            value = self.scorer.value(side) - 400
            self.scorer.remove(r, c)
            return value
        return self.scorer.value(side)


def _root(search: _Search, side: int, depth: int, width: int) -> list[tuple[int, tuple[int, int]]]:
    """根节点：每个候选都开全窗口搜，拿到真实分（避免窄窗口的假分）。"""
    board = search.board
    results: list[tuple[int, tuple[int, int]]] = []
    for r, c in search.ordered_moves(side, width):
        search.scorer.place(r, c, side)
        if board.longest_run(r, c) >= 5:
            search.scorer.remove(r, c)
            results.append((WIN_SCORE, (r, c)))
            continue
        value = -search.negamax(other(side), depth - 1, -INF, INF, 1)
        search.scorer.remove(r, c)
        results.append((value, (r, c)))
    results.sort(key=lambda item: (-item[0], item[1][0], item[1][1]))
    return results


def best_move(
    board: Board,
    side: int,
    depth: int = 3,
    time_limit: float = 1.5,
    margin: int = 400,
    width: int = 10,
    rng: random.Random | None = None,
) -> tuple[int, int] | None:
    """给 side 挑一步。margin 越大，越愿意在"次优"里随机挑，也就越弱。"""
    rng = rng or random
    size = board.size

    if board.is_full():
        return None
    if board.count == 0:
        mid = size // 2
        return (mid, mid)

    # 1) 能成五，直接赢
    wins = winning_points(board, side)
    if wins:
        return rng.choice(wins)

    # 2) 对方能成五，必须堵（堵不住就随便堵一个，反正也输了）
    blocks = winning_points(board, other(side))
    if blocks:
        return rng.choice(blocks) if len(blocks) > 1 else blocks[0]

    # 3) 搜索
    deadline = time.monotonic() + max(0.05, time_limit)
    best_results: list[tuple[int, tuple[int, int]]] | None = None
    for d in range(2, depth + 1):
        search = _Search(board.copy(), deadline, width)
        try:
            results = _root(search, side, d, width + 2)
        except _Timeout:
            break
        best_results = results
        if results and results[0][0] >= WIN_SCORE - 1000:
            break

    if not best_results:
        # 时间太紧，退化成"挑一个最像样的"
        fallback = _Search(board, deadline, width).ordered_moves(side, 1)
        return fallback[0] if fallback else None

    top = best_results[0][0]
    pool = [move for value, move in best_results if value >= top - margin]
    return rng.choice(pool)
