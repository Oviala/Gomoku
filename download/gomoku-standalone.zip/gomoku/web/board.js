/* 棋盘渲染：榉木底、格子、星位、棋子落下 / 涟漪、五连高亮。
 *
 * 只管画。规则和状态都在服务端，app.js 把 snapshot 塞进 state。
 */

const BOARD = {
  SIZE: 15,
  CELL: 40,
  MARGIN: 40,
};
BOARD.W = (BOARD.SIZE - 1) * BOARD.CELL + BOARD.MARGIN * 2;   // 640
BOARD.H = BOARD.W;

const STAR_POINTS = [[3, 3], [3, 11], [7, 7], [11, 3], [11, 11]];
const COL_LABEL = 'ABCDEFGHJKLMNOP';

const clamp01 = (t) => Math.max(0, Math.min(1, t));
const EASE_OUT = (t) => 1 - Math.pow(1 - t, 3);
const EASE_IN = (t) => t * t;

function roundRect(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}

class BoardView {
  constructor(canvas) {
    this.canvas = canvas;
    this.dpr = Math.min(2.5, window.devicePixelRatio || 1);

    canvas.width = Math.round(BOARD.W * this.dpr);
    canvas.height = Math.round(BOARD.H * this.dpr);

    this.g = canvas.getContext('2d');
    this.g.scale(this.dpr, this.dpr);

    this.wood = makeWood(BOARD.W, BOARD.H, this.dpr);
    this.shadow = makeStoneShadow(this.dpr);
    this.stones = buildStoneSprites(this.dpr);

    this.state = {
      board: [], turn: 1, last: null, line: null,
      over: false, winner: null, hover: null, ghostSide: null,
    };

    this.anims = [];
    this.hover = null;
    this.time = 0;

    this.loop = this.loop.bind(this);
    requestAnimationFrame(this.loop);
  }

  setState(patch) {
    Object.assign(this.state, patch);
  }

  xy(r, c) {
    return [BOARD.MARGIN + c * BOARD.CELL, BOARD.MARGIN + r * BOARD.CELL];
  }

  cellAt(px, py) {
    const c = Math.round((px - BOARD.MARGIN) / BOARD.CELL);
    const r = Math.round((py - BOARD.MARGIN) / BOARD.CELL);
    if (r < 0 || r >= BOARD.SIZE || c < 0 || c >= BOARD.SIZE) return null;
    const [cx, cy] = this.xy(r, c);
    if (Math.abs(cx - px) > BOARD.CELL * 0.46 || Math.abs(cy - py) > BOARD.CELL * 0.46) return null;
    return [r, c];
  }

  /* ------------------------------------------------------------ 动画 */
  drop(r, c, side) {
    this.anims = this.anims.filter((a) => !(a.kind === 'drop' && a.r === r && a.c === c));
    this.anims.push({ kind: 'drop', r, c, side, t0: performance.now(), dur: 320, landed: false });
  }

  rippleAt(r, c, color) {
    const [x, y] = this.xy(r, c);
    this.anims.push({
      kind: 'ripple', x, y,
      color: color || 'rgba(255, 245, 215, 0.85)',
      t0: performance.now(), dur: 520,
    });
  }

  /* ------------------------------------------------------------ 主循环 */
  loop(now) {
    this.time = now / 1000;
    this.anims = this.anims.filter((a) => now - a.t0 < a.dur);
    this.draw(now);
    requestAnimationFrame(this.loop);
  }

  draw(now) {
    const g = this.g;
    g.clearRect(0, 0, BOARD.W, BOARD.H);
    g.drawImage(this.wood, 0, 0, BOARD.W, BOARD.H);

    this.drawFrame(g);
    this.drawGrid(g);
    this.drawLabels(g);
    this.drawLastMove(g, now);
    this.drawHover(g);
    this.drawStones(g, now);
    this.drawRipples(g, now);
    this.drawWin(g, now);
  }

  /* ------------------------------------------------------------ 静态 */
  drawFrame(g) {
    const W = BOARD.W;
    // 外围深色木边
    g.save();
    g.strokeStyle = 'rgba(74, 44, 18, 0.85)';
    g.lineWidth = 3;
    g.strokeRect(5.5, 5.5, W - 11, W - 11);
    g.strokeStyle = 'rgba(250, 240, 214, 0.35)';
    g.lineWidth = 1;
    g.strokeRect(7.5, 7.5, W - 15, W - 15);
    g.restore();
  }

  drawGrid(g) {
    const { CELL, SIZE, MARGIN } = BOARD;
    const x0 = MARGIN;
    const y0 = MARGIN;
    const x1 = MARGIN + (SIZE - 1) * CELL;
    const y1 = y0 + (SIZE - 1) * CELL;

    g.save();
    g.lineCap = 'round';

    // 淡淡的描金外框（棋盘本体）
    g.strokeStyle = 'rgba(120, 80, 32, 0.35)';
    g.lineWidth = 2;
    g.strokeRect(x0 - 9, y0 - 9, x1 - x0 + 18, y1 - y0 + 18);

    g.strokeStyle = 'rgba(62, 40, 16, 0.72)';
    g.lineWidth = 1.15;

    for (let i = 0; i < SIZE; i++) {
      const y = y0 + i * CELL;
      g.beginPath();
      g.moveTo(x0, y);
      g.lineTo(x1, y);
      g.stroke();

      const x = x0 + i * CELL;
      g.beginPath();
      g.moveTo(x, y0);
      g.lineTo(x, y1);
      g.stroke();
    }

    // 星位
    g.fillStyle = 'rgba(52, 32, 12, 0.8)';
    for (const [r, c] of STAR_POINTS) {
      const [px, py] = this.xy(r, c);
      g.beginPath();
      g.arc(px, py, 3.4, 0, Math.PI * 2);
      g.fill();
    }
    g.restore();
  }

  drawLabels(g) {
    const { CELL, SIZE, MARGIN } = BOARD;
    g.save();
    g.fillStyle = 'rgba(78, 52, 22, 0.55)';
    g.font = '600 10px "Avenir Next", "PingFang SC", system-ui, sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';

    for (let c = 0; c < SIZE; c++) {
      g.fillText(COL_LABEL[c], MARGIN + c * CELL, MARGIN - 19);
    }
    for (let r = 0; r < SIZE; r++) {
      g.fillText(String(SIZE - r), MARGIN - 20, MARGIN + r * CELL);
    }
    g.restore();
  }

  drawLastMove(g, now) {
    const last = this.state.last;
    if (!last) return;
    const [r, c] = last;
    if (this.anims.some((a) => (a.kind === 'drop' && a.r === r && a.c === c))) return;

    const [x, y] = this.xy(r, c);
    const pulse = (Math.sin(now / 260) + 1) / 2;
    g.save();
    g.strokeStyle = `rgba(198, 146, 44, ${0.55 + pulse * 0.3})`;
    g.lineWidth = 1.8;
    g.beginPath();
    g.arc(x, y, STONE.R + 3.5 + pulse * 1.2, 0, Math.PI * 2);
    g.stroke();

    g.restore();
  }

  drawHover(g) {
    const hover = this.hover;
    if (!hover) return;
    const { board, turn, over, ghostSide } = this.state;
    if (over) return;
    const [r, c] = hover;
    if (board?.[r]?.[c]) return;

    const [x, y] = this.xy(r, c);
    const side = ghostSide || turn;
    drawStone(g, this.stones[side], x, y, { alpha: 0.3, scale: 0.96 });
    g.save();
    g.strokeStyle = 'rgba(150, 102, 32, 0.55)';
    g.lineWidth = 1.4;
    g.setLineDash([4, 4]);
    g.beginPath();
    g.arc(x, y, STONE.R + 1.5, 0, Math.PI * 2);
    g.stroke();
    g.restore();
  }

  /* ------------------------------------------------------------ 棋子 */
  drawStones(g, now) {
    const { board } = this.state;
    const dropping = new Map();
    for (const a of this.anims) {
      if (a.kind === 'drop') dropping.set(a.r * 100 + a.c, a);
    }

    for (let r = 0; r < BOARD.SIZE; r++) {
      for (let c = 0; c < BOARD.SIZE; c++) {
        const side = board?.[r]?.[c];
        if (!side) continue;
        if (dropping.has(r * 100 + c)) continue;
        const [x, y] = this.xy(r, c);
        this.drawOne(g, side, x, y, 1);
      }
    }

    for (const a of dropping.values()) {
      const p = clamp01((now - a.t0) / a.dur);
      const [x, y] = this.xy(a.r, a.c);
      const fall = 84 * (1 - EASE_IN(p));
      const near = p;
      const shadowAlpha = 0.18 + 0.42 * near;
      const shadowScale = 1.5 - 0.45 * near;
      g.save();
      g.globalAlpha = shadowAlpha;
      g.drawImage(
        this.shadow,
        x - (this.shadow.__w * shadowScale) / 2,
        y - (this.shadow.__h * shadowScale) / 2 + 5,
        this.shadow.__w * shadowScale,
        this.shadow.__h * shadowScale,
      );
      g.restore();

      // 快落地时轻微压扁
      const land = p > 0.82 ? (p - 0.82) / 0.18 : 0;
      const sy = 1 - 0.16 * Math.sin(Math.PI * land);
      const sx = 1 + 0.10 * Math.sin(Math.PI * land);

      g.save();
      g.translate(x, y - fall);
      g.scale(sx, sy);
      g.translate(-x, -y);
      // 下落中只画棋子本体：地面的影子留在落点，不跟着飞，免得看起来像重影
      drawStone(g, this.stones[a.side], x, y, { alpha: 1 });
      g.restore();

      if (!a.landed && p > 0.9) {
        a.landed = true;
        this.rippleAt(a.r, a.c);
      }
    }
  }

  drawOne(g, side, x, y, alpha) {
    const shadow = this.shadow;
    g.save();
    g.globalAlpha = 0.5 * alpha;
    g.drawImage(shadow, x - shadow.__w / 2, y - shadow.__h / 2 + 4.5, shadow.__w, shadow.__h);
    g.restore();
    drawStone(g, this.stones[side], x, y, { alpha });
  }

  drawRipples(g, now) {
    for (const a of this.anims) {
      if (a.kind !== 'ripple') continue;
      const p = clamp01((now - a.t0) / a.dur);
      const rr = STONE.R * (1 + p * 1.9);
      g.save();
      g.globalAlpha = (1 - p) * 0.75;
      g.strokeStyle = a.color;
      g.lineWidth = 3.2 * (1 - p) + 0.6;
      g.beginPath();
      g.arc(a.x, a.y, rr, 0, Math.PI * 2);
      g.stroke();
      g.restore();
    }
  }

  /* ------------------------------------------------------------ 胜负 */
  drawWin(g, now) {
    const { over, line, winner } = this.state;
    if (!over) return;

    g.save();
    g.fillStyle = 'rgba(24, 12, 4, 0.34)';
    g.fillRect(0, 0, BOARD.W, BOARD.H);
    g.restore();

    if (line && line.length >= 5) {
      const [x0, y0] = this.xy(line[0][0], line[0][1]);
      const [x1, y1] = this.xy(line[line.length - 1][0], line[line.length - 1][1]);
      const pulse = (Math.sin(now / 240) + 1) / 2;

      g.save();
      g.lineCap = 'round';
      g.shadowColor = 'rgba(255, 214, 120, 0.9)';
      g.shadowBlur = 14 + pulse * 8;
      const grad = g.createLinearGradient(x0, y0, x1, y1);
      grad.addColorStop(0, 'rgba(255, 226, 150, 0.75)');
      grad.addColorStop(0.5, 'rgba(255, 244, 210, 0.98)');
      grad.addColorStop(1, 'rgba(255, 226, 150, 0.75)');
      g.strokeStyle = grad;
      g.lineWidth = 4.5;
      g.beginPath();
      g.moveTo(x0, y0);
      g.lineTo(x1, y1);
      g.stroke();
      g.restore();

      for (const [r, c] of line) {
        const [x, y] = this.xy(r, c);
        g.save();
        g.strokeStyle = `rgba(255, 236, 170, ${0.55 + pulse * 0.35})`;
        g.lineWidth = 2.4;
        g.beginPath();
        g.arc(x, y, STONE.R + 4.5 + pulse * 2.5, 0, Math.PI * 2);
        g.stroke();
        g.restore();
      }
    }

    const winnerName = winner === 1 ? '黑方胜' : winner === 2 ? '白方胜' : '和棋';
    const sub = winner === 1 || winner === 2 ? '五 连' : '棋盘已满';
    const w = 200;
    const h = 88;
    const x = (BOARD.W - w) / 2;
    const y = BOARD.H - h - 26;       // 放到底部，别挡住连子

    g.save();
    g.shadowColor = 'rgba(0, 0, 0, 0.6)';
    g.shadowBlur = 24;
    g.fillStyle = 'rgba(34, 18, 6, 0.88)';
    roundRect(g, x, y, w, h, 14);
    g.fill();
    g.shadowBlur = 0;
    g.strokeStyle = 'rgba(240, 210, 140, 0.55)';
    g.lineWidth = 1.4;
    roundRect(g, x + 0.5, y + 0.5, w - 1, h - 1, 14);
    g.stroke();

    g.fillStyle = '#f6e2b4';
    g.font = '700 30px "Songti SC", "STSong", serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(winnerName, BOARD.W / 2, y + 35);

    g.fillStyle = 'rgba(226, 200, 150, 0.75)';
    g.font = '400 13px "Songti SC", "STSong", serif';
    g.fillText(sub, BOARD.W / 2, y + 63);
    g.restore();
  }
}
