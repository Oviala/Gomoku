"""棋盘数据：15×15 交叉点，0 空 / 1 黑 / 2 白。

只管摆子、拿子、找邻居，胜负判断放在 rules.py。
"""

from __future__ import annotations

SIZE = 15
EMPTY = 0
BLACK = 1
WHITE = 2

# 四个方向：竖、横、正斜（\）、反斜（/）
DIRS = ((1, 0), (0, 1), (1, 1), (1, -1))

SIDE_NAME = {BLACK: "黑方", WHITE: "白方"}
SIDE_CODE = {BLACK: "b", WHITE: "w"}


def other(side: int) -> int:
    """换边。"""
    return WHITE if side == BLACK else BLACK


def side_name(side: int) -> str:
    return SIDE_NAME.get(side, "—")


class Board:
    """一块 15×15 的棋盘。

    `near` 记录"每个空点周围两格内有没有棋子"，用来快速生成候选点，
    落子 / 提子时增量维护，避免每次都扫全盘。
    """

    def __init__(self, size: int = SIZE) -> None:
        self.size = size
        self.grid = [[EMPTY] * size for _ in range(size)]
        self.count = 0
        self._near: dict[tuple[int, int], int] = {}

    # ------------------------------------------------------------ 基本
    def inside(self, r: int, c: int) -> bool:
        return 0 <= r < self.size and 0 <= c < self.size

    def at(self, r: int, c: int) -> int:
        if not self.inside(r, c):
            return EMPTY
        return self.grid[r][c]

    def place(self, r: int, c: int, side: int) -> None:
        self.grid[r][c] = side
        self.count += 1
        self._touch_near(r, c, +1)

    def remove(self, r: int, c: int) -> None:
        self.grid[r][c] = EMPTY
        self.count -= 1
        self._touch_near(r, c, -1)

    def is_empty(self, r: int, c: int) -> bool:
        return self.inside(r, c) and self.grid[r][c] == EMPTY

    def is_full(self) -> bool:
        return self.count >= self.size * self.size

    def copy(self) -> "Board":
        clone = Board(self.size)
        clone.grid = [row[:] for row in self.grid]
        clone.count = self.count
        clone._near = dict(self._near)
        return clone

    # ------------------------------------------------------------ 候选点
    def _touch_near(self, r: int, c: int, delta: int) -> None:
        for dr in range(-2, 3):
            for dc in range(-2, 3):
                if dr == 0 and dc == 0:
                    continue
                rr, cc = r + dr, c + dc
                if not self.inside(rr, cc):
                    continue
                key = (rr, cc)
                value = self._near.get(key, 0) + delta
                if value > 0:
                    self._near[key] = value
                else:
                    self._near.pop(key, None)

    def candidates(self) -> list[tuple[int, int]]:
        """所有空着的、周围两格内有棋子的点。"""
        return [(r, c) for (r, c) in self._near if self.grid[r][c] == EMPTY]

    # ------------------------------------------------------------ 线
    def line_cells(self, r: int, c: int, dr: int, dc: int) -> list[tuple[int, int]]:
        """经过 (r, c)、方向 (dr, dc) 的整条线上的所有交叉点（按顺序）。"""
        cells: list[tuple[int, int]] = []
        rr, cc = r, c
        while self.inside(rr - dr, cc - dc):
            rr -= dr
            cc -= dc
        while self.inside(rr, cc):
            cells.append((rr, cc))
            rr += dr
            cc += dc
        return cells

    def run(self, r: int, c: int, dr: int, dc: int) -> list[tuple[int, int]]:
        """(r, c) 所在方向上，与它同色的连续一段（含自己），按顺序返回。"""
        side = self.grid[r][c]
        if side == EMPTY:
            return []

        back: list[tuple[int, int]] = []
        rr, cc = r - dr, c - dc
        while self.inside(rr, cc) and self.grid[rr][cc] == side:
            back.append((rr, cc))
            rr -= dr
            cc -= dc

        forward: list[tuple[int, int]] = []
        rr, cc = r + dr, c + dc
        while self.inside(rr, cc) and self.grid[rr][cc] == side:
            forward.append((rr, cc))
            rr += dr
            cc += dc

        return list(reversed(back)) + [(r, c)] + forward

    def longest_run(self, r: int, c: int) -> int:
        """(r, c) 处的棋子在四个方向上能连成的最长一段。"""
        best = 0
        for dr, dc in DIRS:
            best = max(best, len(self.run(r, c, dr, dc)))
        return best

    # ------------------------------------------------------------ 展示
    def stones(self) -> list[tuple[int, int, int]]:
        return [
            (r, c, self.grid[r][c])
            for r in range(self.size)
            for c in range(self.size)
            if self.grid[r][c] != EMPTY
        ]

    def __repr__(self) -> str:  # pragma: no cover - 调试用
        mark = {EMPTY: ".", BLACK: "X", WHITE: "O"}
        return "\n".join("".join(mark[v] for v in row) for row in self.grid)
