@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PORT=8766

curl -s -o nul --max-time 1 http://127.0.0.1:%PORT%/ >nul 2>nul
if %errorlevel%==0 (
  start "" http://127.0.0.1:%PORT%/
  exit /b 0
)

where py >nul 2>nul
if %errorlevel%==0 (
  start "gomoku" /min py -3 server.py
  goto wait
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "gomoku" /min python server.py
  goto wait
)

echo.
echo 没找到 Python。请先到 https://www.python.org/downloads/ 安装 Python 3，
echo 安装时记得勾选 "Add Python to PATH"，装完再双击一次本文件。
echo.
pause
exit /b 1

:wait
timeout /t 2 >nul
start "" http://127.0.0.1:%PORT%/
