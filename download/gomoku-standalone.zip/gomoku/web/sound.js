/* 音效：全部用 Web Audio 现场合成，不加载任何音频文件。
 *
 * 落子 = 高频"嗒"（带通噪声）+ 木头/石头的低频 body，黑子沉稳、白子清脆；
 * 第二下轻磕是棋子落定那一下。胜利是一串五声音阶的钟声。
 *
 * 浏览器不允许自动播放，所以 AudioContext 在第一次触摸/点击时才真正启动。
 * 合成函数都写成 (ctx, dest, ...)，这样自测里可以用 OfflineAudioContext
 * 离线渲染一遍、量一下有没有声音，而不是"看代码觉得应该有声"。
 */

const Sound = (() => {
  const KEY = 'gomoku-sound';

  let ctx = null;
  let master = null;
  let noise = null;
  // 隐私模式下 localStorage 可能直接抛错，读不到就当"开着"
  function readPref() {
    try {
      return localStorage.getItem(KEY) !== '0';
    } catch (e) {
      return true;
    }
  }

  function writePref(value) {
    try {
      localStorage.setItem(KEY, value ? '1' : '0');
    } catch (e) {
      /* 存不了就算了 */
    }
  }

  let enabled = readPref();

  /* ------------------------------------------------------------ 合成基元 */
  function makeNoise(ac, dur = 0.5) {
    const len = Math.floor(ac.sampleRate * dur);
    const buffer = ac.createBuffer(1, len, ac.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    return buffer;
  }

  function clickBurst(ac, dest, buffer, freq, gain, when, dur = 0.07) {
    const src = ac.createBufferSource();
    src.buffer = buffer;
    const bp = ac.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = freq;
    bp.Q.value = 2.2;
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(gain, when + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    src.connect(bp);
    bp.connect(g);
    g.connect(dest);
    src.start(when, Math.random() * 0.2, dur + 0.02);
  }

  function bodyTone(ac, dest, freq, gain, dur, when, glide = 0.7) {
    const osc = ac.createOscillator();
    const g = ac.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, when);
    osc.frequency.exponentialRampToValueAtTime(freq * glide, when + dur);
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(gain, when + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    osc.connect(g);
    g.connect(dest);
    osc.start(when);
    osc.stop(when + dur + 0.02);
  }

  function bell(ac, dest, freq, when, gain = 0.14, dur = 1.6) {
    const partials = [[1, 1, 1], [2.01, 0.38, 0.72], [2.98, 0.16, 0.5], [5.4, 0.07, 0.3]];
    for (const [ratio, amp, dec] of partials) {
      const osc = ac.createOscillator();
      const g = ac.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq * ratio;
      g.gain.setValueAtTime(0.0001, when);
      g.gain.exponentialRampToValueAtTime(gain * amp, when + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, when + dur * dec);
      osc.connect(g);
      g.connect(dest);
      osc.start(when);
      osc.stop(when + dur * dec + 0.05);
    }
  }

  /* ------------------------------------------------------------ 四种声音 */
  function placeAt(ac, dest, buffer, side, when, volume = 1) {
    const v = 0.9 * volume;
    const bright = side === 1 ? 2350 : 3050;
    const body = side === 1 ? 176 : 214;

    // 敲在木头上的一瞬
    clickBurst(ac, dest, buffer, bright * (0.95 + Math.random() * 0.1), 0.5 * v, when, 0.07);
    // 棋子落定时的第二下轻磕
    clickBurst(ac, dest, buffer, bright * 1.55, 0.11 * v, when + 0.036, 0.05);
    // 木质 / 石质共鸣
    bodyTone(ac, dest, body * (0.97 + Math.random() * 0.06), 0.2 * v, 0.16, when);
    bodyTone(ac, dest, body * 2.6, 0.05 * v, 0.075, when, 0.85);
  }

  function winAt(ac, dest, when) {
    // 五声音阶上行：C D E G C
    const notes = [523.25, 587.33, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => bell(ac, dest, freq, when + i * 0.115, 0.13));
    bell(ac, dest, 261.63, when + 0.02, 0.06, 2.4);
  }

  function undoAt(ac, dest, buffer, when) {
    // 一段往下扫的气声，像把棋子轻轻收回去
    const src = ac.createBufferSource();
    src.buffer = buffer;
    const lp = ac.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(1600, when);
    lp.frequency.exponentialRampToValueAtTime(220, when + 0.22);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(0.16, when + 0.03);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 0.24);
    src.connect(lp);
    lp.connect(g);
    g.connect(dest);
    src.start(when, 0.1, 0.26);
    bodyTone(ac, dest, 320, 0.07, 0.18, when, 0.6);
  }

  function clickAt(ac, dest, buffer, when) {
    clickBurst(ac, dest, buffer, 3200, 0.075, when, 0.03);
  }

  /* ------------------------------------------------------------ 实时播放 */
  function ensure() {
    if (!enabled) return null;
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      try {
        ctx = new AC();
      } catch (e) {
        return null;
      }
      master = ctx.createGain();
      master.gain.value = 0.8;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -16;
      comp.knee.value = 22;
      comp.ratio.value = 5;
      master.connect(comp);
      comp.connect(ctx.destination);
      noise = makeNoise(ctx);
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  }

  function place(side = 1, volume = 1) {
    const ac = ensure();
    if (!ac) return;
    placeAt(ac, master, noise, side, ac.currentTime + 0.002, volume);
  }

  function win() {
    const ac = ensure();
    if (!ac) return;
    winAt(ac, master, ac.currentTime + 0.05);
  }

  function undo() {
    const ac = ensure();
    if (!ac) return;
    undoAt(ac, master, noise, ac.currentTime + 0.01);
  }

  function click() {
    const ac = ensure();
    if (!ac) return;
    clickAt(ac, master, noise, ac.currentTime + 0.001);
  }

  /* ------------------------------------------------------------ 自测用 */
  async function testRender(kind) {
    const AC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (!AC) return 0;
    const ac = new AC(1, Math.floor(44100 * 1.4), 44100);
    const dest = ac.createGain();
    dest.gain.value = 1;
    dest.connect(ac.destination);
    const buffer = makeNoise(ac);

    if (kind === 'place') placeAt(ac, dest, buffer, 1, 0.02, 1);
    else if (kind === 'place-white') placeAt(ac, dest, buffer, 2, 0.02, 1);
    else if (kind === 'win') winAt(ac, dest, 0.05);
    else if (kind === 'undo') undoAt(ac, dest, buffer, 0.02);
    else clickAt(ac, dest, buffer, 0.02);

    const rendered = await ac.startRendering();
    const data = rendered.getChannelData(0);
    let peak = 0;
    for (let i = 0; i < data.length; i++) {
      const v = Math.abs(data[i]);
      if (v > peak) peak = v;
    }
    return peak;
  }

  /* ------------------------------------------------------------ 开关 */
  function setEnabled(value) {
    enabled = !!value;
    writePref(enabled);
    if (!enabled && ctx && ctx.state === 'running') {
      try { ctx.suspend(); } catch (e) { /* ignore */ }
    }
  }

  function unlock() {
    if (enabled) ensure();
  }

  return {
    place,
    win,
    undo,
    click,
    unlock,
    setEnabled,
    isEnabled: () => enabled,
    testRender,
  };
})();
