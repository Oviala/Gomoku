"""规则：连五即胜（无禁手，长连也算赢），棋盘下满为和棋。"""

from __future__ import annotations

from .board import BLACK, DIRS, EMPTY, WHITE, Board

WIN_LEN = 5


def winning_line(board: Board, r: int, c: int) -> list[tuple[int, int]] | None:
    """(r, c) 刚落的这颗子是否连成五；成了就把整段连子返回。"""
    side = board.at(r, c)
    if side == EMPTY:
        return None
    for dr, dc in DIRS:
        cells = board.run(r, c, dr, dc)
        if len(cells) >= WIN_LEN:
            return cells
    return None


def is_win(board: Board, r: int, c: int) -> bool:
    return winning_line(board, r, c) is not None


def would_win(board: Board, r: int, c: int, side: int) -> bool:
    """假设 side 在空点 (r, c) 落子，会不会立刻连成五。"""
    if not board.is_empty(r, c):
        return False
    board.grid[r][c] = side
    try:
        return is_win(board, r, c)
    finally:
        board.grid[r][c] = EMPTY


def winning_points(board: Board, side: int) -> list[tuple[int, int]]:
    """side 下一手能直接连成五的所有空点（冲四点）。

    只在"有棋子附近"的空点里找 —— 能凑成五的点一定紧挨着至少一颗同色子。
    这里直接数两个方向上的连子，不摆子/不建列表，搜索里会调到很多次。
    """
    grid = board.grid
    size = board.size
    points: list[tuple[int, int]] = []
    for r, c in board.candidates():
        for dr, dc in DIRS:
            count = 1
            rr, cc = r + dr, c + dc
            while 0 <= rr < size and 0 <= cc < size and grid[rr][cc] == side:
                count += 1
                rr += dr
                cc += dc
            rr, cc = r - dr, c - dc
            while 0 <= rr < size and 0 <= cc < size and grid[rr][cc] == side:
                count += 1
                rr -= dr
                cc -= dc
            if count >= WIN_LEN:
                points.append((r, c))
                break
    return points


def is_draw(board: Board) -> bool:
    """和棋：棋盘下满。胜负在落子那一刻就已经判过了。"""
    return board.is_full()
