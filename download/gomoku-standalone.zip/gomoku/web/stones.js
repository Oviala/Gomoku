/* 棋子与棋盘贴图：预渲染成 canvas，主循环里直接 drawImage。
 *
 * 五子棋的子是圆润的贝壳/石材：
 *   黑子 = 黑曜石（冷色高光 + 下缘反光 + 细颗粒）
 *   白子 = 蛤贝/白玉（暖色高光 + 石纹 + 边缘泛黄）
 * 侧面厚度用底部一圈深色过渡 + 投影表现，俯视角度也能看出"厚"。
 */

const STONE = {
  R: 17,      // 半径
  PAD: 7,     // 贴图留白（阴影/抗锯齿）
};

const STONE_SIDE = { 1: 'black', 2: 'white' };

function mulberry32(seed) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------------------------------------------------------------- 棋子 */
function makeStoneSprite(side, dpr) {
  const R = STONE.R;
  const PAD = STONE.PAD;
  const W = R * 2 + PAD * 2;
  const H = W;

  const cv = document.createElement('canvas');
  cv.width = Math.round(W * dpr);
  cv.height = Math.round(H * dpr);
  const g = cv.getContext('2d');
  g.scale(dpr, dpr);

  const cx = W / 2;
  const cy = H / 2 - 0.6;          // 稍微抬高，给下缘留出厚度
  const rnd = mulberry32(side === 1 ? 91117 : 33011);
  const black = side === 1;

  // ---------------------------------------------------------------- 底面厚度
  // 往下的暗色椭圆，模拟石子放在棋盘上的圆边
  g.save();
  g.beginPath();
  g.ellipse(cx, cy + 1.6, R * 0.99, R * 0.99, 0, 0, Math.PI * 2);
  const under = g.createLinearGradient(0, cy, 0, cy + R);
  under.addColorStop(0, black ? 'rgba(0,0,0,0.55)' : 'rgba(120,104,80,0.35)');
  under.addColorStop(1, black ? 'rgba(0,0,0,0.9)' : 'rgba(120,104,80,0.65)');
  g.fillStyle = under;
  g.fill();
  g.restore();

  // ---------------------------------------------------------------- 主体
  const base = g.createRadialGradient(
    cx - R * 0.32, cy - R * 0.36, R * 0.08,
    cx + R * 0.08, cy + R * 0.18, R * 1.12,
  );
  if (black) {
    base.addColorStop(0, '#5a5f6d');
    base.addColorStop(0.32, '#33363f');
    base.addColorStop(0.7, '#16171c');
    base.addColorStop(1, '#050506');
  } else {
    base.addColorStop(0, '#fffef9');
    base.addColorStop(0.38, '#fbf5e6');
    base.addColorStop(0.7, '#efe4cd');
    base.addColorStop(0.9, '#ddcdaf');
    base.addColorStop(1, '#c3b091');
  }
  g.beginPath();
  g.arc(cx, cy, R, 0, Math.PI * 2);
  g.fillStyle = base;
  g.fill();

  // ---------------------------------------------------------------- 石纹
  g.save();
  g.beginPath();
  g.arc(cx, cy, R - 0.6, 0, Math.PI * 2);
  g.clip();

  if (black) {
    // 黑曜石：细颗粒 + 两道隐约的流纹
    for (let i = 0; i < 46; i++) {
      const a = rnd() * Math.PI * 2;
      const d = Math.sqrt(rnd()) * R * 0.94;
      g.beginPath();
      g.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 0.4 + rnd() * 0.9, 0, Math.PI * 2);
      g.fillStyle = `rgba(190, 200, 220, ${0.03 + rnd() * 0.07})`;
      g.fill();
    }
    for (let i = 0; i < 3; i++) {
      const y0 = cy - R * 0.5 + i * R * 0.42;
      g.beginPath();
      g.moveTo(cx - R, y0);
      g.bezierCurveTo(cx - R * 0.3, y0 - 3, cx + R * 0.3, y0 + 3, cx + R, y0 - 1);
      g.strokeStyle = `rgba(160, 175, 205, ${0.025 + rnd() * 0.02})`;
      g.lineWidth = 0.8 + rnd();
      g.stroke();
    }
  } else {
    // 白子：整体干净，只留极细的暖色斑点
    for (let i = 0; i < 18; i++) {
      const a = rnd() * Math.PI * 2;
      const d = Math.sqrt(rnd()) * R * 0.9;
      g.beginPath();
      g.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 0.5 + rnd() * 1.1, 0, Math.PI * 2);
      g.fillStyle = `rgba(170, 146, 108, ${0.03 + rnd() * 0.05})`;
      g.fill();
    }
  }
  g.restore();

  // ---------------------------------------------------------------- 高光
  const hx = cx - R * 0.36;
  const hy = cy - R * 0.42;
  const hi = g.createRadialGradient(hx, hy, 0, hx, hy, R * 0.86);
  hi.addColorStop(0, black ? 'rgba(232, 240, 255, 0.55)' : 'rgba(255, 255, 255, 0.95)');
  hi.addColorStop(0.22, black ? 'rgba(210, 222, 245, 0.22)' : 'rgba(255, 255, 255, 0.45)');
  hi.addColorStop(0.55, 'rgba(255, 255, 255, 0.06)');
  hi.addColorStop(0.8, 'rgba(255, 255, 255, 0.015)');
  hi.addColorStop(1, 'rgba(255, 255, 255, 0)');
  g.beginPath();
  g.arc(cx, cy, R, 0, Math.PI * 2);
  g.fillStyle = hi;
  g.fill();

  // 高光点（灯下的反光）：用径向渐变而不是实心椭圆，边缘才不硬
  g.save();
  const sx = cx - R * 0.40;
  const sy = cy - R * 0.44;
  const spot = g.createRadialGradient(sx, sy, 0, sx, sy, R * 0.26);
  spot.addColorStop(0, black ? 'rgba(255, 255, 255, 0.85)' : 'rgba(255, 255, 255, 1)');
  spot.addColorStop(0.45, black ? 'rgba(255, 255, 255, 0.35)' : 'rgba(255, 255, 255, 0.55)');
  spot.addColorStop(1, 'rgba(255, 255, 255, 0)');
  g.fillStyle = spot;
  g.beginPath();
  g.arc(sx, sy, R * 0.26, 0, Math.PI * 2);
  g.fill();
  g.restore();

  // 白子的暖色内阴影，让它不像一块塑料
  if (!black) {
    const inner = g.createRadialGradient(cx, cy, R * 0.55, cx, cy, R);
    inner.addColorStop(0, 'rgba(140, 110, 66, 0)');
    inner.addColorStop(0.82, 'rgba(140, 110, 66, 0.05)');
    inner.addColorStop(1, 'rgba(120, 92, 50, 0.22)');
    g.beginPath();
    g.arc(cx, cy, R, 0, Math.PI * 2);
    g.fillStyle = inner;
    g.fill();
  }

  // ---------------------------------------------------------------- 边缘
  // 下缘反光（对着光的那一侧）
  g.beginPath();
  g.arc(cx, cy, R - 1.1, Math.PI * 0.18, Math.PI * 0.82);
  g.strokeStyle = black ? 'rgba(150, 175, 215, 0.30)' : 'rgba(255, 252, 240, 0.8)';
  g.lineWidth = 1.5;
  g.stroke();

  // 外沿描边
  g.beginPath();
  g.arc(cx, cy, R - 0.4, 0, Math.PI * 2);
  g.strokeStyle = black ? 'rgba(0, 0, 0, 0.9)' : 'rgba(112, 92, 62, 0.7)';
  g.lineWidth = 1.2;
  g.stroke();

  cv.__w = W;
  cv.__h = H;
  return cv;
}

function buildStoneSprites(dpr) {
  return { 1: makeStoneSprite(1, dpr), 2: makeStoneSprite(2, dpr) };
}

/** 把棋子画到 (x, y)（圆心）。 */
function drawStone(g, sprite, x, y, opts = {}) {
  const scale = opts.scale ?? 1;
  const alpha = opts.alpha ?? 1;
  if (alpha <= 0 || scale <= 0) return;
  const W = sprite.__w;
  const H = sprite.__h;

  g.save();
  g.globalAlpha = alpha;
  if (scale !== 1) {
    g.translate(x, y);
    g.scale(scale, scale);
    g.translate(-x, -y);
  }
  g.drawImage(sprite, x - W / 2, y - H / 2, W, H);
  g.restore();
}

/* ---------------------------------------------------------------- 投影 */
function makeStoneShadow(dpr) {
  const R = STONE.R;
  const w = R * 2.7;
  const h = R * 1.9;
  const cv = document.createElement('canvas');
  cv.width = Math.round(w * dpr);
  cv.height = Math.round(h * dpr);
  const g = cv.getContext('2d');
  g.scale(dpr, dpr);

  const grad = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
  grad.addColorStop(0, 'rgba(40, 24, 8, 0.55)');
  grad.addColorStop(0.5, 'rgba(40, 24, 8, 0.30)');
  grad.addColorStop(1, 'rgba(40, 24, 8, 0)');
  g.fillStyle = grad;
  g.beginPath();
  g.ellipse(w / 2, h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
  g.fill();

  cv.__w = w;
  cv.__h = h;
  return cv;
}

/* ---------------------------------------------------------------- 棋盘 */
function makeWood(w, h, dpr) {
  const cv = document.createElement('canvas');
  cv.width = Math.round(w * dpr);
  cv.height = Math.round(h * dpr);
  const g = cv.getContext('2d');
  g.scale(dpr, dpr);

  const rnd = mulberry32(20250429);

  // 榉木底色：暖黄，右上略亮
  const base = g.createLinearGradient(0, 0, w * 0.85, h);
  base.addColorStop(0, '#e8cb96');
  base.addColorStop(0.3, '#e2c088');
  base.addColorStop(0.62, '#d7b076');
  base.addColorStop(1, '#c79c62');
  g.fillStyle = base;
  g.fillRect(0, 0, w, h);

  // 竖纹
  for (let i = 0; i < 240; i++) {
    const x = rnd() * w;
    const amp = 3 + rnd() * 10;
    const freq = 0.006 + rnd() * 0.012;
    const phase = rnd() * Math.PI * 2;
    g.beginPath();
    for (let y = -10; y <= h + 10; y += 8) {
      const xx = x + Math.sin(y * freq + phase) * amp;
      if (y === -10) g.moveTo(xx, y);
      else g.lineTo(xx, y);
    }
    g.strokeStyle = `rgba(120, 82, 40, ${0.02 + rnd() * 0.05})`;
    g.lineWidth = 0.5 + rnd() * 2;
    g.stroke();
  }

  // 几道深色木纹（更细更淡）
  for (let i = 0; i < 26; i++) {
    const x = rnd() * w;
    g.beginPath();
    g.moveTo(x, 0);
    g.bezierCurveTo(x + 8, h * 0.3, x - 8, h * 0.7, x + 4, h);
    g.strokeStyle = `rgba(96, 62, 26, ${0.03 + rnd() * 0.04})`;
    g.lineWidth = 1 + rnd() * 1.6;
    g.stroke();
  }

  // 木结
  for (let i = 0; i < 4; i++) {
    const kx = rnd() * w;
    const ky = rnd() * h;
    const kr = 10 + rnd() * 18;
    for (let ring = 0; ring < 3; ring++) {
      g.beginPath();
      g.ellipse(kx, ky, kr + ring * 4, (kr + ring * 4) * 0.35, rnd() * 0.5, 0, Math.PI * 2);
      g.strokeStyle = `rgba(110, 74, 34, ${0.04 + rnd() * 0.03})`;
      g.lineWidth = 1;
      g.stroke();
    }
  }

  // 轻微暗角，让棋盘不"飘"
  const vig = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.34,
    w / 2, h / 2, Math.max(w, h) * 0.76);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(0.75, 'rgba(80, 44, 12, 0.10)');
  vig.addColorStop(1, 'rgba(60, 30, 6, 0.26)');
  g.fillStyle = vig;
  g.fillRect(0, 0, w, h);

  cv.__w = w;
  cv.__h = h;
  return cv;
}
